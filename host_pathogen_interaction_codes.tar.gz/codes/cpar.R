library(DESeq2)
library("RColorBrewer")
colors <-  brewer.pal(8, "Set1")
source("https://bioconductor.org/biocLite.R")
library(reshape2)
library(ggplot2)
library(ggrepel)
library(tibble)   ### for inserting coulmn in dataframe
library(EDASeq)
library(RUVSeq)
library(GO.db)
library(clusterProfiler)
library(org.Hs.eg.db)
library(VennDiagram)
library(openxlsx)

### In current directory, create "cpar" directory. Put the files cpar_human_data.txt, cpar_yeast_data.txt and cpar_go.txt in current directory.

setwd("~/Dropbox/Project_Jena/Results_shared/Plots_and_Suppl/codes/")
yeast_with_e_and_D<-read.table("./cpar_yeast_data.txt",check.names = FALSE)
human_with_e_and_D<-read.table("./cpar_human_data.txt",check.names = FALSE)



yeast_with_e_and_D<-as.matrix(yeast_with_e_and_D)
human_with_e_and_D<-as.matrix(human_with_e_and_D)


### remove e and D columns
yeast <- subset(yeast_with_e_and_D, select = -c(D7,D8,D9))
human <- subset(human_with_e_and_D, select = -c(D7,D8,D9))


##################################################

detach("package:RUVSeq", unload=TRUE)   ### detach RUVSeq because it interferes with some functions of DESeq2
detach("package:EDASeq", unload=TRUE)   ### detach EDASeq because it interferes with some functions of DESeq2

### Combine technical replicates
yeast<-as.data.frame(yeast)
yeast<-add_column(yeast, "36+reseq" = yeast$`36`+yeast$`36reseq`, .after = "35")
yeast$`36`<-NULL
yeast$`36reseq`<-NULL


yeast<-add_column(yeast, "37+reseq" = yeast$`37`+yeast$`37reseq`, .after = "36+reseq")
yeast$`37`<-NULL
yeast$`37reseq`<-NULL


human<-as.data.frame(human)
human<-add_column(human, "36+reseq" = human$`36`+human$`36reseq`, .after = "35")
human$`36`<-NULL
human$`36reseq`<-NULL

human<-add_column(human, "37+reseq" = human$`37`+human$`37reseq`, .after = "36+reseq")
human$`37`<-NULL
human$`37reseq`<-NULL

############## for pca in all_spp_comparison

CPAR_data<-yeast
write.table(CPAR_data,"./cpar/CPAR_counts.txt", quote = F, row.names = T, sep = "\t")


########## DESeq2 analysis yeast #######
colData_yeast<-data.frame(time=factor(x=c(rep("0",2), rep("3",3), rep("12", 3), rep("24",3), rep("24c",2)),levels=c("0","3","12","24", "24c")))
pre_dds_parap <- DESeqDataSetFromMatrix(yeast, colData=colData_yeast, ~time)
dds_parap <- DESeq(pre_dds_parap)
all_parap_data_norm<-vst(dds_parap)
plot_parap<-plotPCA(all_parap_data_norm, intgroup="time", ntop=5000)

png('./cpar/PCA_cpar_ntop5000.png', units="in", width=7, heigh=7, res=300)
plot_parap+geom_text_repel(aes(label=colnames(all_parap_data_norm)),show.legend = FALSE)+
  scale_colour_discrete(name="Time points")+ theme_bw()+labs("PCA of C. parapsilosis")
dev.off()


##### all compared with 0 time point########
res_cpar_0_3 <- results(dds_parap, cooksCutoff=FALSE, contrast = c("time","3","0"))
write.table(res_cpar_0_3, file="./cpar/res_cpar_0_vs_3.txt", sep = "\t", quote = FALSE)

res_cpar_0_12 <- results(dds_parap, cooksCutoff=FALSE, contrast = c("time","12","0"))
write.table(res_cpar_0_12, file="./cpar/res_cpar_0_vs_12.txt", sep = "\t", quote = FALSE)

res_cpar_0_24 <- results(dds_parap, cooksCutoff=FALSE, contrast = c("time","24","0"))
write.table(res_cpar_0_24, file="./cpar/res_cpar_0_vs_24.txt", sep = "\t", quote = FALSE)

res_cpar_0_24c <- results(dds_parap, cooksCutoff=FALSE, contrast = c("time","24c","0"))
write.table(res_cpar_0_24c, file="./cpar/res_cpar_0_vs_24c.txt", sep = "\t", quote = FALSE)


############# Plotting transcriptome dynamics ###########################


all_data<-cbind.data.frame(res_cpar_0_3$log2FoldChange,res_cpar_0_3$padj,
                           res_cpar_0_12$log2FoldChange,res_cpar_0_12$padj,
                           res_cpar_0_24$log2FoldChange,res_cpar_0_24$padj)


rownames(all_data)<-rownames(res_cpar_0_12)
colnames(all_data)<-c("3", "padj3", "12", "padj12", "24", "padj24") #, "24c", "padj24c")

all_data<-all_data[complete.cases(all_data),]


all_data$`3`[all_data$padj3 > 0.01] <- 0
all_data$`12`[all_data$padj12 > 0.01] <- 0
all_data$`24`[all_data$padj24 > 0.01] <- 0


LFC<-cbind.data.frame("0" = 0, all_data$`3`, all_data$`12`, all_data$`24`)
colnames(LFC)<-c("0","3","12", "24")
rownames(LFC)<-rownames(all_data)

####################plotting interpolated values############################################


LFC<-LFC[apply(LFC, 1, function(x) !all(x==0)),]

############ Plotting of interpolated LFC #################3

time<-c(0,3,12,24)
time_interpol<-approx(time)$y


LFC_no_NA<-LFC[complete.cases(LFC),]
LFC_no_NA_t<-t(LFC_no_NA)

### Interpolation
interpol_LFC<-apply(LFC_no_NA_t, 2, approx)

### rbind only y values from interpol_LFC

combined_interplolated<-do.call(rbind, lapply(interpol_LFC, '[[','y'))

### parsing and plotting
colnames(combined_interplolated)<-time_interpol

LFC_plotting_inter<-melt(combined_interplolated,value.name = "value", varnames=c('Var1', 'Var2'))


png('./cpar/cpar_dyn.png', units="in", width=5, heigh=3, res=400)
ggplot(data=LFC_plotting_inter, aes(x=LFC_plotting_inter$Var2, y=LFC_plotting_inter$value, group=LFC_plotting_inter$Var1, colour=LFC_plotting_inter$value)) +
  geom_line() + xlab("Time (h)")+ylab("Log2 fold change") + 
  scale_colour_gradient2(low = "blue", mid = "grey", high = "red",space = "Lab",na.value = "grey50", guide = "colourbar")+theme_bw()+labs(colour = "L2FC\ngradient")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size=18),
        legend.text = element_text(size=14),legend.title = element_text(size=14),
        axis.ticks.x=element_blank())+
  scale_y_continuous(breaks=seq(-14,14,4)) + expand_limits(y=c(-14,14))+scale_x_continuous(breaks=c(0, 3, 12, 24))### add this to change ticks
dev.off()


##########################  HUMAN PART   ################################

human_controls<-read.table("./calb_human_data.txt",check.names = F)

all_human_data<-cbind.data.frame("1"=human_controls$`1`, "2"=human_controls$`2`, human, "17"=human_controls$`17`, "18"=human_controls$`18`) 

### DESEQ2 ###

colData_human<-data.frame(time=factor(x=c(rep("0",2), rep("3",3), rep("12", 3), rep("24",3), rep("24c",2)),levels=c("0","3","12","24", "24c")))


pre_dds_human <- DESeqDataSetFromMatrix(all_human_data, colData=colData_human, ~time)
dds_human <- DESeq(pre_dds_human)
all_human_data_norm<-vst(dds_human)
plot_human<-plotPCA(all_human_data_norm, intgroup="time", ntop=5000)


png('./cpar/PCA_human_cpar_ntop5000.png', units="in", width=7, heigh=7, res=300)
plot_human+geom_text_repel(aes(label=colnames(all_human_data_norm)), show.legend = FALSE)+
  scale_colour_discrete(name  ="Time points")+ theme_bw()+labs("PCA of human samples interacting with C. parapsilosis")
dev.off()


##### all compared with 0 time point########
res_cpar_human_0_3 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","3","0"))
write.table(res_cpar_human_0_3, file="./cpar/res_human_cpar_0_vs_3.txt", sep = "\t", quote = FALSE)

res_cpar_human_0_12 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","12","0"))
write.table(res_cpar_human_0_12, file="./cpar/res_human_cpar_0_vs_12.txt", sep = "\t", quote = FALSE)

res_cpar_human_0_24 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","24","0"))
write.table(res_cpar_human_0_24, file="./cpar/res_human_cpar_0_vs_24.txt", sep = "\t", quote = FALSE)

res_cpar_human_0_24c <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","24c","0"))
write.table(res_cpar_human_0_24c, file="./cpar/res_human_cpar_0_vs_24c.txt", sep = "\t", quote = FALSE)


#########Plotting of interpolated LFC #####################
all_data<-cbind.data.frame(res_cpar_human_0_3$log2FoldChange,res_cpar_human_0_3$padj,
                           res_cpar_human_0_12$log2FoldChange,res_cpar_human_0_12$padj,
                           res_cpar_human_0_24$log2FoldChange,res_cpar_human_0_24$padj)


rownames(all_data)<-rownames(res_cpar_human_0_12)
colnames(all_data)<-c("3", "padj3", "12", "padj12", "24", "padj24") #, "24c", "padj24c")

all_data<-all_data[complete.cases(all_data),]


all_data$`3`[all_data$padj3 > 0.01] <- 0
all_data$`12`[all_data$padj12 > 0.01] <- 0
all_data$`24`[all_data$padj24 > 0.01] <- 0


LFC<-cbind.data.frame("0" = 0, all_data$`3`, all_data$`12`, all_data$`24`)
colnames(LFC)<-c("0","3","12", "24")
rownames(LFC)<-rownames(all_data)


################## FILTERING 
LFC<-LFC[apply(LFC, 1, function(x) !all(x==0)),]

############ Plotting of interpolated LFC #################3

time<-c(0,3,12,24)
time_interpol<-approx(time)$y


LFC_no_NA<-LFC[complete.cases(LFC),]
LFC_no_NA_t<-t(LFC_no_NA)

### Interpolation
interpol_LFC<-apply(LFC_no_NA_t, 2, approx)

### rbind only y values from interpol_LFC

combined_interplolated<-do.call(rbind, lapply(interpol_LFC, '[[','y'))

### parsing and plotting
colnames(combined_interplolated)<-time_interpol

LFC_plotting_inter<-melt(combined_interplolated,value.name = "value", varnames=c('Var1', 'Var2'))


png('./cpar/human_cpar_dyn.png', units="in", width=5, heigh=2.5, res=400)
ggplot(data=LFC_plotting_inter, aes(x=LFC_plotting_inter$Var2, y=LFC_plotting_inter$value, group=LFC_plotting_inter$Var1, colour=LFC_plotting_inter$value)) +
  geom_line() + xlab("Time (h)")+ylab("Log2 fold change") + 
  scale_colour_gradient2(low = "blue", mid = "grey", high = "red",space = "Lab",na.value = "grey50", guide = "colourbar")+theme_bw()+labs(colour = "L2FC\ngradient")+
  theme(axis.text = element_text(size = 14),axis.title = element_text(size=14),
        legend.text = element_text(size=14),legend.title = element_text(size=14),
        axis.title.x=element_blank(),
        axis.ticks.y=element_blank())+labs(colour = "L2FC\ngradient")+
  scale_y_continuous(breaks=seq(-8,8,2))+expand_limits(y=c(-8,8))+scale_x_continuous(breaks=c(0, 3, 12, 24)) ### this is for changing ticks
dev.off()


########## test LRT############

##### cpar
colData_yeast_lrt<-data.frame(time=factor(x=c(rep("0",2), rep("3",3), rep("12", 3), rep("24",3)),levels=c("0","3","12","24")))
yeast_lrt<-yeast[,-c(dim(yeast)[2]-1,dim(yeast)[2])] ### remove last two columns

pre_dds_cpar_lrt <- DESeqDataSetFromMatrix(yeast_lrt, colData=colData_yeast_lrt, ~time)

dds_lrt_cpar <- DESeq(pre_dds_cpar_lrt, test="LRT", reduced=~1)
res_lrt_cpar <- results(dds_lrt_cpar)
write.table(res_lrt_cpar, file="./cpar/res_lrt_cpar.txt", sep = "\t", quote = FALSE)


non_DE_cpar<-res_lrt_cpar[!is.na(res_lrt_cpar$padj) & res_lrt_cpar$padj>0.5 & res_lrt_cpar$baseMean>100,]
write.table(non_DE_cpar, file="./cpar/non_DE_cpar.txt", sep = "\t", quote = FALSE)

#### human
colData_human_lrt<-data.frame(time=factor(x=c(rep("0",2), rep("3",3), rep("12", 3), rep("24",3)),levels=c("0","3","12","24")))
human_lrt<-all_human_data[,-c(dim(all_human_data)[2]-1,dim(all_human_data)[2])] ### remove last two columns

pre_dds_human_cpar_lrt <- DESeqDataSetFromMatrix(human_lrt, colData=colData_human_lrt, ~time)

dds_lrt_human_cpar <- DESeq(pre_dds_human_cpar_lrt, test="LRT", reduced=~1)
res_lrt_human_cpar <- results(dds_lrt_human_cpar)
write.table(res_lrt_human_cpar, file="./cpar/res_lrt_human_cpar.txt", sep = "\t", quote = FALSE)



non_DE_cpar_human <- res_lrt_human_cpar[!is.na(res_lrt_human_cpar$padj) & res_lrt_human_cpar$padj>0.5 & res_lrt_human_cpar$baseMean>100,]

##########################################

### 24 vs 24c comparison

genes_cpar_0_24<-rownames(res_cpar_0_24[!is.na(res_cpar_0_24$padj) & res_cpar_0_24$padj<0.01,])
genes_cpar_0_24c<-rownames(res_cpar_0_24c[!is.na(res_cpar_0_24c$padj) & res_cpar_0_24c$padj<0.01,])
overlap<-as.data.frame(Reduce(intersect,list(genes_cpar_0_24,genes_cpar_0_24c)))


venn.diagram(list("cpar_0_24"=genes_cpar_0_24,
                  "cpar_0_24c"=genes_cpar_0_24c),
             fill=c("green", "cornflowerblue"), height = 2500, width = 2500, resolution = 600, 
             main = "C. parap. DE genes between 24h and 24h control", cat.cex=0.4, cex=1.8, main.cex = 0.7, 
             filename="./cpar/cpar_24_24c.png",  
             imagetype = "png")

only_infection_cpar<-setdiff(genes_cpar_0_24, genes_cpar_0_24c)
subset_0vs24<-res_cpar_0_24[only_infection_cpar,]
write.table(subset_0vs24,"cpar/infection_genes_cpar_24_24c.txt", quote = FALSE, sep = "\t")


#######Comparison with dead cells
library(EDASeq)
library(RUVSeq)


human_D<-cbind(all_human_data[,1:5],human_with_e_and_D[,5:7], all_human_data[,6:13])

colData_D<-data.frame(batch=c(rep("1",5),rep("2",3),rep("1",8)))

###removing batch effect
human_D_set <- newSeqExpressionSet(as.matrix(human_D),
                                   phenoData = cbind(colData_D,row.names=colnames(human_D)))

human_D_removed_batch_effect <- RUVg(human_D_set, row.names(non_DE_cpar_human), k=1)


colData_D_mod<-data.frame(time=factor(x=c(rep("0",2),rep("3",3), rep("3D",3), rep("12", 3), 
                                      rep("24",3), rep("24c",2)),levels=c("0","3","3D","12","24","24c")),
                           W=pData(human_D_removed_batch_effect)[,2])


### DESEQ2 ###
pre_dds_human_D_no_batch <- DESeqDataSetFromMatrix(counts(human_D_removed_batch_effect), colData_D_mod, ~W+time)
dds_human_D_no_batch <- DESeq(pre_dds_human_D_no_batch)

all_data_nobatch_norm<-vst(dds_human_D_no_batch)
vst_data_no_batch<-assay(all_data_nobatch_norm)
pca <- prcomp(t(vst_data_no_batch))
percentVar <- pca$sdev^2/sum(pca$sdev^2)

df_plotting<-data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2],colData_D_mod) ### do PC2 = pca$x[, 2]*-1 to invert values

ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=time), size=4)+
  geom_text_repel(aes(label=colnames(all_data_nobatch_norm)), show.legend = FALSE)


res_cpar_human_0_3D_no_batch <- results(dds_human_D_no_batch, cooksCutoff=FALSE, contrast = c("time","3D","0"))

### Creating a supplementary xlsx file


res_cpar_human_0_3D<-res_cpar_human_0_3D_no_batch
res_cpar_human_lrt<-res_lrt_human_cpar
res_cpar_lrt<-res_lrt_cpar

wb_S8 <- createWorkbook("Supp_file_S8")

header<-c("gene", "baseMean","log2FoldChange","lfcSE","stat","pvalue","padj")
fungal_data_files<-c("res_cpar_0_3",
                     "res_cpar_0_12",
                     "res_cpar_0_24",
                     "res_cpar_0_24c",
                     "res_cpar_lrt",
                     "subset_0vs24")

human_data_files<-c("res_cpar_human_0_3",
                    "res_cpar_human_0_12",
                    "res_cpar_human_0_24",
                    "res_cpar_human_0_24c",
                    "res_cpar_human_lrt",
                    "res_cpar_human_0_3D")

file_names<-c(fungal_data_files,human_data_files)
descriptions<-c("C. parapsilosis at 3 hpi compared to 0 h control",
                "C. parapsilosis at 12 hpi compared to 0 h control",
                "C. parapsilosis at 24 hpi compared to 0 h control",
                "C. parapsilosis at 24 h control compared to 0 h control",
                "LRT test for C. parapsilosis samples (differential expression at any time point)",
                "Species-specific DE genes in C. parapsilosis (DE exclusively during infection)",
                "Human cells interacting with C. parapsilosis at 3 hpi compared to 0 h control",
                "Human cells interacting with C. parapsilosis at 12 hpi compared to 0 h control",
                "Human cells interacting with C. parapsilosis at 24 hpi compared to 0 h control",
                "Human cells at 24 h control compared 0 h control",
                "LRT test of human cells interacting with C. parapsilosis (differential expression at any time point)",
                "Human cells interacting with killed C. parapsilosis at 3 hpi compared to 0 h control")

sheets_and_descriptions<-cbind.data.frame("Data_sheets"=file_names,"Description"=descriptions)

addWorksheet(wb_S8,"Sheets_and_descriptions")
writeData(wb_S8, "Sheets_and_descriptions", sheets_and_descriptions,keepNA = T)

for (file in fungal_data_files){
  assign("fung",as.data.frame(eval(parse(text=paste0(file)))))
  fung <- cbind("genes"=rownames(fung), data.frame(fung, row.names=NULL))
  addWorksheet(wb_S8, file)
  writeData(wb_S8, file, fung,keepNA = T)
}

for (file in human_data_files){
  assign("hum",as.data.frame(eval(parse(text=paste0(file)))))
  hum<-hum[complete.cases(hum),]
  hum <- cbind("genes"=rownames(hum), data.frame(hum, row.names=NULL))
  addWorksheet(wb_S8, file)
  writeData(wb_S8, file, hum, keepNA = T)
}

saveWorkbook(wb_S8, "./cpar/Supp_File_S8.xlsx", overwrite = TRUE)


### GO TERMS CPAR. One should create "fungi" directory in current directory.

### Finding MF,BP and CC terms
all_go_tems<-as.data.frame(GOTERM)

all_go_tems<-all_go_tems[!(all_go_tems$go_id %in% c("GO:0003674","GO:0008150","GO:0005575")),]


MF_terms<-all_go_tems$go_id[all_go_tems$Ontology=="MF"]
BP_terms<-all_go_tems$go_id[all_go_tems$Ontology=="BP"]
CC_terms<-all_go_tems$go_id[all_go_tems$Ontology=="CC"]


### Association of GOID with description
goterms <- Term(GOTERM)
a<-as.data.frame(goterms)
go_names<-cbind(row.names(a),a)


### CPAR GOIDS
cpar_go<-read.table("./cpar_go.txt")


MF_universe<-cpar_go[cpar_go$V1 %in% MF_terms,]
BP_universe<-cpar_go[cpar_go$V1 %in% BP_terms,]
CC_universe<-cpar_go[cpar_go$V1 %in% CC_terms,]



fungal_goterms<-function(file,name,ont){
ego<-enricher(file, pvalueCutoff = 0.05, 
         pAdjustMethod = "BH", universe = eval(parse(text=paste0(ont,"_universe$V2"))),minGSSize = 2, 
         maxGSSize = NA, TERM2GENE = eval(parse(text=paste0(ont,"_universe"))),TERM2NAME = go_names)
          if (!is.null(ego)){

            p<-dotplot(ego,showCategory = 30)
            p+ggplot2::ggsave(sprintf("./cpar/fungi/%s_%s.png",name,ont),
                  units="in", width=10, heigh=7, dpi=600)
            write.table(ego,sprintf("./cpar/fungi/%s_%s.txt",name,ont), sep = "\t")
  
          }
}


for (comp in fungal_data_files){
  for (ontology in c("BP","MF","CC")){
    data<- eval(parse(text = c(comp)))
    
    assign(paste0(comp,"_up"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange>1.5,]))
    assign(paste0(comp,"_down"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange< -1.5,]))
    
    fungal_goterms(eval(parse(text = paste0(comp,"_up"))),paste0(comp,"_up"),ontology)
    fungal_goterms(eval(parse(text = paste0(comp,"_down"))),paste0(comp,"_down"),ontology)
  }
}



### HUMAN GO TERMS. One should create "human" directory in current directory.


human_goterms<-function(file,name,ontology){
ego<-enrichGO(file, 
			OrgDb = org.Hs.eg.db,
			keyType = "ENSEMBL",
			pvalueCutoff = 0.05, 
			pAdjustMethod = "BH",
			ont = ontology)
      if (!is.null(ego)){
        p<-dotplot(ego,showCategory = 30)
        p+ggplot2::ggsave(sprintf("./cpar/human/%s_%s.png",name,ontology),
                  units="in", width=10, heigh=7, dpi=600)
        write.table(ego,sprintf("./cpar/human/%s_%s.txt",name,ontology), sep = "\t")

  }
}


for (comp in human_data_files){
  for (ontology in c("BP","MF","CC")){
    data <- eval(parse(text = c(comp)))
    
    assign(paste0(comp,"_up"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange>1.5,]))
    assign(paste0(comp,"_down"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange< -1.5,]))
    
    human_goterms(eval(parse(text = paste0(comp,"_up"))),paste0(comp,"_up"),ontology)
    human_goterms(eval(parse(text = paste0(comp,"_down"))),paste0(comp,"_down"),ontology)
  }
}

