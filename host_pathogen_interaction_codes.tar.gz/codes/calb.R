library(DESeq2)
library(RColorBrewer)
library(reshape2)
library(ggplot2)
library(ggrepel)
library(tibble)   ### for inserting coulmn in dataframe
library(EDASeq)
library(RUVSeq)
library(GO.db)
library(clusterProfiler)
library(org.Hs.eg.db)
library(VennDiagram)
library(openxlsx)

### Set the working direcorty to the downloaded folder.

human_with_e_and_D<-read.table("./calb_human_data.txt",check.names = FALSE)
yeast_with_e_and_D<-read.table("./calb_yeast_data.txt",check.names = FALSE)


human_with_e_and_D<-as.matrix(human_with_e_and_D)
yeast_with_e_and_D<-as.matrix(yeast_with_e_and_D)

### remove e and D columns, corresponding to ece1 mutant and dead-cells samples
yeast <- subset(yeast_with_e_and_D, select = -c(e4,e5,e6,D1,D2,D3,e7,e8,e9,e1,e2,e3))
human <- subset(human_with_e_and_D, select = -c(D1,D2,D3,e7,e8,e9))

####################################################

detach("package:RUVSeq", unload=TRUE)   ### detach RUVSeq because it interferes with some functions of DESeq2
detach("package:EDASeq", unload=TRUE)   ### detach EDASeq because it interferes with some functions of DESeq2



### Combine technical replicates

yeast<-as.data.frame(yeast)
yeast<-add_column(yeast, "A0C1+reseq" = yeast$A0C1+yeast$A0C1reseq, .after = "2")
yeast$A0C1<-NULL
yeast$A0C1reseq<-NULL


yeast<-add_column(yeast, "A0C2+reseq" = yeast$A0C2+yeast$A0C2reseq, .after = "A0C1+reseq")
yeast$A0C2<-NULL
yeast$A0C2reseq<-NULL


yeast<-add_column(yeast, "3plus3reseq" = yeast$`3`+yeast$`3reseq`, .after = "A0C2+reseq")
yeast$`3reseq`<-NULL
yeast$`3`<-NULL


yeast<-add_column(yeast, "A24C1+reseq" = yeast$A24C1+yeast$A24C1reseq, .after = "18")
yeast$A24C1<-NULL
yeast$A24C1reseq<-NULL


yeast<-add_column(yeast, "A24C2+reseq" = yeast$A24C2+yeast$A24C2reseq, .after = "A24C1+reseq")
yeast$A24C2<-NULL
yeast$A24C2reseq<-NULL


human<-as.data.frame(human)
human<-add_column(human, "3plus3reseq" = human$`3`+human$`3reseq`, .after = "2")
human$`3reseq`<-NULL
human$`3`<-NULL


#### The output is produced to use in all_spp_comparison.R script. ADDING ECE1 SAMPLES

CALB_data<-cbind(yeast, yeast_with_e_and_D[,c("e4","e5","e6","e7","e8","e9","e1","e2","e3")])

write.table(CALB_data,"./calb/CALB_counts.txt", quote = F, row.names = T,sep = "\t")


########## DESeq2 analysis yeast #######

colData_yeast<-data.frame(time=factor(x=c(rep("0",4), rep("1.5",3), rep("3",3), rep("3c",2), rep("12", 3), rep("24",4), rep("24c",4)), levels=c("0","1.5","3","3c","12","24", "24c")))
pre_dds_alb <- DESeqDataSetFromMatrix(yeast, colData=colData_yeast, ~time)
dds_alb <- DESeq(pre_dds_alb)
all_alb_data_norm<-vst(dds_alb)
plot_alb<-plotPCA(all_alb_data_norm, intgroup="time", ntop=5000)

png('~/Dropbox/Project_Jena/Results_shared/Plots_and_Suppl/codes/PCA_calb_ntop5000.png', units="in", width=7, heigh=7, res=300)
plot_alb+geom_text_repel(aes(label=colnames(all_alb_data_norm)), show.legend = FALSE)+
  scale_colour_discrete(name="Time points")+ theme_bw()+labs("PCA for C. albicans")
dev.off()


##### all compared with 0 time point########
res_calb_0_1.5 <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","1.5","0"))
write.table(res_calb_0_1.5, file="./calb/res_calb_0_vs_1.5.txt", sep = "\t", quote = FALSE)

res_calb_0_3 <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","3","0"))
write.table(res_calb_0_3, file="./calb/res_calb_0_vs_3.txt", sep = "\t", quote = FALSE)

res_calb_0_3c <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","3c","0"))
write.table(res_calb_0_3c, file="./calb/res_calb_0_vs_3c.txt", sep = "\t", quote = FALSE)

res_calb_0_12 <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","12","0"))
write.table(res_calb_0_12, file="./calb/res_calb_0_vs_12.txt", sep = "\t", quote = FALSE)

res_calb_0_24 <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","24","0"))
write.table(res_calb_0_24, file="./calb/res_calb_0_vs_24.txt", sep = "\t", quote = FALSE)

res_calb_0_24c <- results(dds_alb, cooksCutoff=FALSE, contrast = c("time","24c","0"))
write.table(res_calb_0_24c, file="./calb/res_calb_0_vs_24c.txt", sep = "\t", quote = FALSE)


############# Plotting transcriptome dynamics ###########################


all_data<-cbind.data.frame(res_calb_0_3$log2FoldChange,res_calb_0_3$padj,
                           res_calb_0_12$log2FoldChange,res_calb_0_12$padj,
                           res_calb_0_24$log2FoldChange,res_calb_0_24$padj)


rownames(all_data)<-rownames(res_calb_0_12)
colnames(all_data)<-c("3", "padj3", "12", "padj12", "24", "padj24") #, "24c", "padj24c")


all_data<-all_data[complete.cases(all_data),]

all_data$`3`[all_data$padj3 > 0.01] <- 0
all_data$`12`[all_data$padj12 > 0.01] <- 0
all_data$`24`[all_data$padj24 > 0.01] <- 0


LFC<-cbind.data.frame("0" = 0, all_data$`3`, all_data$`12`, all_data$`24`)
colnames(LFC)<-c("0","3","12", "24")
rownames(LFC)<-rownames(all_data)

################## FILTERING !!!
LFC<-LFC[apply(LFC, 1, function(x) !all(x==0)),]    ### discard gene with no changes in expression

############ Plotting of interpolated LFC #################3
time<-c(0,3,12,24)
time_interpol<-approx(time)$y

LFC_no_NA<-LFC[complete.cases(LFC),]
LFC_no_NA_t<-t(LFC_no_NA)

### Interpolation
interpol_LFC<-apply(LFC_no_NA_t, 2, approx)

### rbind only y values from interpol_LFC

combined_interplolated<-do.call(rbind, lapply(interpol_LFC, '[[','y'))

### parsing and plotting
colnames(combined_interplolated)<-time_interpol

LFC_plotting_inter<-melt(combined_interplolated,value.name = "value", varnames=c('Var1', 'Var2'))

png('./calb/calb_dyn.png', units="in", width=5, heigh=3, res=400)
ggplot(data=LFC_plotting_inter, aes(x=LFC_plotting_inter$Var2, y=LFC_plotting_inter$value, group=LFC_plotting_inter$Var1, colour=LFC_plotting_inter$value)) +
  geom_line() + xlab("Time (h)")+ylab("Log2 fold change") +
  scale_colour_gradient2(low = "blue", mid = "grey", high = "red",space = "Lab",na.value = "grey50", guide = "colourbar")+theme_bw()+labs(colour = "L2FC\ngradient")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size=18),
        legend.text = element_text(size=14),legend.title = element_text(size=14),
        axis.ticks.x=element_blank())+
  scale_y_continuous(breaks=seq(-14,14,4)) + expand_limits(y=c(-14,14))+scale_x_continuous(breaks=c(0, 3, 12, 24))### add this to change ticks
dev.off()


##########################  HUMAN PART   ################################

### DESeq2 ###

colData_human<-data.frame(time=factor(x=c(rep("0",2), rep("1.5",3),rep("3",3), rep("12", 3), rep("24",4), rep("24c",2)),levels=c("0","1.5","3","12","24", "24c")))
all_human_data<-human


pre_dds_human <- DESeqDataSetFromMatrix(all_human_data, colData=colData_human, ~time)
dds_human <- DESeq(pre_dds_human)

all_human_data_norm<-vst(dds_human)
plot_human<-plotPCA(all_human_data_norm, intgroup="time", ntop=5000)

png('./calb/PCA_human_calb_ntop5000.png', units="in", width=7, heigh=7, res=300)
plot_human+geom_text_repel(aes(label=colnames(all_human_data_norm)), show.legend = FALSE)+
  scale_colour_discrete(name="Time points")+ theme_bw()+labs("PCA plots of human samples grown with C. albicans")
dev.off()

##### all compared with 0 time point########
res_calb_human_0_1.5 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","1.5","0"))
write.table(res_calb_human_0_1.5, file="./calb/res_human_calb_0_vs_1.5.txt", sep = "\t", quote = FALSE)

res_calb_human_0_3 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","3","0"))
write.table(res_calb_human_0_3, file="./calb/res_human_calb_0_vs_3.txt", sep = "\t", quote = FALSE)

res_calb_human_0_12 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","12","0"))
write.table(res_calb_human_0_12, file="./calb/res_human_calb_0_vs_12.txt", sep = "\t", quote = FALSE)

res_calb_human_0_24 <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","24","0"))
write.table(res_calb_human_0_24, file="./calb/res_human_calb_0_vs_24.txt", sep = "\t", quote = FALSE)

res_calb_human_0_24c <- results(dds_human, cooksCutoff=FALSE, contrast = c("time","24c","0"))
write.table(res_calb_human_0_24c, file="./calb/res_human_calb_0_vs_24c.txt", sep = "\t", quote = FALSE)

######### Plotting transcirpotme dynamics for human #####################
all_data<-cbind.data.frame(res_calb_human_0_3$log2FoldChange,res_calb_human_0_3$padj,
                           res_calb_human_0_12$log2FoldChange,res_calb_human_0_12$padj,
                           res_calb_human_0_24$log2FoldChange,res_calb_human_0_24$padj)

rownames(all_data)<-rownames(res_calb_human_0_12)
colnames(all_data)<-c("3", "padj3", "12", "padj12", "24", "padj24") #, "24c", "padj24c")


all_data<-all_data[complete.cases(all_data),]


all_data$`3`[all_data$padj3 > 0.01] <- 0
all_data$`12`[all_data$padj12 > 0.01] <- 0
all_data$`24`[all_data$padj24 > 0.01] <- 0


LFC<-cbind.data.frame("0" = 0, all_data$`3`, all_data$`12`, all_data$`24`)
colnames(LFC)<-c("0","3","12", "24")
rownames(LFC)<-rownames(all_data)

################## FILTERING
LFC<-LFC[apply(LFC, 1, function(x) !all(x==0)),]

############ Plotting of interpolated LFC #################

time<-c(0,3,12,24)
time_interpol<-approx(time)$y


LFC_no_NA<-LFC[complete.cases(LFC),]

LFC_no_NA_t<-t(LFC_no_NA)

### Interpolation
interpol_LFC<-apply(LFC_no_NA_t, 2, approx)

### rbind only y values from interpol_LFC

combined_interplolated<-do.call(rbind, lapply(interpol_LFC, '[[','y'))

### parsing and plotting
colnames(combined_interplolated)<-time_interpol

LFC_plotting_inter<-melt(combined_interplolated,value.name = "value", varnames=c('Var1', 'Var2'))


png('./calb/human_calb_dyn.png', units="in", width=5, heigh=2.5, res=400)
ggplot(data=LFC_plotting_inter, aes(x=LFC_plotting_inter$Var2, y=LFC_plotting_inter$value, group=LFC_plotting_inter$Var1, colour=LFC_plotting_inter$value)) +
  geom_line() + xlab("Time (h)")+ylab("Log2 fold change") + 
  scale_colour_gradient2(low = "blue", mid = "grey", high = "red",space = "Lab",na.value = "grey50", guide = "colourbar")+theme_bw()+
  theme(axis.text = element_text(size = 14),axis.title = element_text(size=14),
        legend.text = element_text(size=14),legend.title = element_text(size=14),
        axis.title.x=element_blank())+labs(colour = "L2FC\ngradient")+
  scale_y_continuous(breaks=seq(-8,8,2))+expand_limits(y=c(-8,8))+scale_x_continuous(breaks=c(0, 3, 12, 24)) ### this is for changing ticks
dev.off()

########## test LRT ############

##### calb

colData_yeast_lrt<-data.frame(time=factor(x=c(rep("0",4), rep("1.5",3), rep("3",3), rep("12", 3), rep("24",4)), levels=c("0","1.5","3","12","24")))

yeast_lrt<-yeast[,-c(11,12,20,21,22,23)] ### remove 3h controls and 4 last columns (24 h controls)

pre_dds_calb_lrt <- DESeqDataSetFromMatrix(yeast_lrt, colData=colData_yeast_lrt, ~time)

dds_lrt_calb <- DESeq(pre_dds_calb_lrt, test="LRT", reduced=~1)
res_lrt_calb <- results(dds_lrt_calb)
write.table(res_lrt_calb, file="./calb/res_lrt_calb.txt", sep = "\t", quote = FALSE)

non_DE_calb<-res_lrt_calb[!is.na(res_lrt_calb$padj) & res_lrt_calb$padj>0.5 & res_lrt_calb$baseMean>100,]
write.table(non_DE_calb, file="./calb/non_DE_calb.txt", sep = "\t", quote = FALSE)


#### human

colData_human_lrt<-data.frame(time=factor(x=c(rep("0",2), rep("1.5",3), rep("3",3), rep("12", 3), rep("24",4)),levels=c("0","1.5","3","12","24")))
human_lrt<-all_human_data[,-c(dim(all_human_data)[2]-1,dim(all_human_data)[2])] ### remove last two columns

pre_dds_human_calb_lrt <- DESeqDataSetFromMatrix(human_lrt, colData=colData_human_lrt, ~time)

dds_lrt_human_calb <- DESeq(pre_dds_human_calb_lrt, test="LRT", reduced=~1)
res_lrt_human_calb <- results(dds_lrt_human_calb)
write.table(res_lrt_human_calb, file="./calb/res_lrt_human_calb.txt", sep = "\t", quote = FALSE)

non_DE_calb_human<-res_lrt_human_calb[!is.na(res_lrt_human_calb$padj) & res_lrt_human_calb$padj>0.5 & res_lrt_human_calb$baseMean>100,]



##########################################

### 24 infection vs 24c comparison

genes_calb_0_24<-rownames(res_calb_0_24[!is.na(res_calb_0_24$padj) & res_calb_0_24$padj<0.01,])

genes_calb_0_24c<-rownames(res_calb_0_24c[!is.na(res_calb_0_24c$padj) & res_calb_0_24c$padj<0.01,])

overlap<-as.data.frame(Reduce(intersect,list(genes_calb_0_24,genes_calb_0_24c)))


venn.diagram(list("calb_0_24"=genes_calb_0_24,
                  "calb_0_24c"=genes_calb_0_24c),
             fill=c("red", "blue"), height = 2500, width = 2500, resolution = 600, 
             main = "C. albicans DE genes between 24h and 24h control", cat.cex=0.4, cex=1.8, main.cex = 0.7, 
             filename="./calb/calb_24_24c.png",  
             imagetype = "png")

only_infection_calb<-setdiff(genes_calb_0_24, genes_calb_0_24c)
subset_0vs24<-res_calb_0_24[only_infection_calb,]
write.table(subset_0vs24,"calb/infection_genes_calb_24_24c.txt", quote = FALSE, sep = "\t")


#######Comparison with dead cells and ece1
library(EDASeq)
library(RUVSeq)


##### 0 vs 3D samples (human samples interacting with dead fungal cells)########

human_D<-cbind(human[,1:8],human_with_e_and_D[,10:12], human[,9:15], human_with_e_and_D[,20:24])

colData_D<-data.frame(batch=c(rep("1",8),rep("2",3),rep("1",7),rep("2",3),rep("1",2)))


###removing batch effect
human_D_set <- newSeqExpressionSet(as.matrix(human_D),
                                   phenoData = cbind(colData_D,row.names=colnames(human_D)))

human_D_removed_batch_effect <- RUVg(human_D_set, row.names(non_DE_calb_human), k=2)

### DESEQ2 ###
colData_D_mod<-data.frame(time=factor(x=c(rep("0",2), rep("1.5",3),rep("3",3), rep("3D",3), rep("12", 3), 
                                          rep("24",4),rep("24e",3), rep("24c",2)),levels=c("0","1.5","3","3D","12","24","24e", "24c")),
                          W=pData(human_D_removed_batch_effect)[,2:3])

rownames(colData_D_mod)=colnames(human_D_removed_batch_effect)

#### This will analyze non batch-corrected counts as recommended by authors. To get a PCA plot with batch corrected counts do  DESeqDataSetFromMatrix(normCounts(human_D_removed_batch_effect), colData=colData_D_mod, ~W_1+time)
pre_dds_human_D_no_batch <- DESeqDataSetFromMatrix(counts(human_D_removed_batch_effect), colData=colData_D_mod, ~W.W_1+W.W_2+time)

dds_human_D_no_batch <- DESeq(pre_dds_human_D_no_batch)

res_calb_human_0_3D_no_batch <- results(dds_human_D_no_batch, cooksCutoff=FALSE, contrast = c("time","3D","0"))
res_calb_human_3_3D_no_batch <- results(dds_human_D_no_batch, cooksCutoff=FALSE, contrast = c("time","3D","3"))
res_calb_human_0_24e_no_batch <- results(dds_human_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24e","0"))
res_calb_human_24_24e_no_batch <- results(dds_human_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24e","24"))

### ECE1 CALB

calb_ece1<-cbind(yeast[,1:4],yeast_with_e_and_D[,7:9],yeast[,5:19],yeast_with_e_and_D[,29:31],yeast[,20:23],yeast_with_e_and_D[,38:40])

colData_yeast<-data.frame(batch=c(rep("1",4),rep("2",3),rep("1",15),rep("2",3),rep("1",4),rep("2",3)))


#### Removing batch effect

calb_ece1_set <- newSeqExpressionSet(as.matrix(calb_ece1),
                                     phenoData = cbind(colData_yeast,row.names=colnames(calb_ece1)))

calb_ece1_removed_batch_effect <- RUVg(calb_ece1_set, row.names(non_DE_calb), k=2)


colData_yeast_mod<-data.frame(time=factor(x=c(rep("0",4),rep("0ece1",3), rep("1.5",3), rep("3",3),rep("3c",2), rep("12", 3), rep("24",4),rep("24ece1",3) ,rep("24c",4),rep("24ece1_c",3)), 
                                          levels=c("0","0ece1","1.5","3","3c","12","24","24ece1","24c","24ece1_c")),
                              W=pData(calb_ece1_removed_batch_effect)[,2:3])

rownames(colData_yeast_mod)<-colnames(calb_ece1_removed_batch_effect)

### DESeq2

### For normal downstream analysis we use non batch-corrected counts
pre_dds_calb_D_no_batch <- DESeqDataSetFromMatrix(counts(calb_ece1_removed_batch_effect), colData=colData_yeast_mod, ~W.W_1+W.W_2+time)
dds_calb_D_no_batch <- DESeq(pre_dds_calb_D_no_batch)

res_calb_0_vs_0e <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","0ece1","0"))
res_calb_0e_vs_24e <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24ece1","0ece1"))
res_calb_0_vs_24e <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24ece1","0"))
res_calb_24e.c_vs_24e <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24ece1","24ece1_c"))
res_calb_24_vs_24e <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24ece1","24"))
res_calb_0e_vs_24e.c <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24ece1_c","0ece1"))
res_calb_0e_vs_24c <- results(dds_calb_D_no_batch, cooksCutoff=FALSE, contrast = c("time","24c","0ece1"))

### For doing PCA we use batch-corrected counts normCounts(calb_ece1_removed_batch_effect)
pre_dds_calb_D_no_batch_for_pca <- DESeqDataSetFromMatrix(normCounts(calb_ece1_removed_batch_effect), colData=colData_yeast_mod, ~W.W_1+W.W_2+time)
dds_calb_D_no_batch_for_pca <- DESeq(pre_dds_calb_D_no_batch_for_pca)

calb_ece1_norm_for_pca<-vst(dds_calb_D_no_batch_for_pca, blind = F)
plot_calb_ece1<-plotPCA(calb_ece1_norm_for_pca, intgroup="time", ntop=5000)
plot_calb_ece1+geom_text_repel(aes(label=colnames(calb_ece1_norm_for_pca)), show.legend = FALSE)+
  scale_colour_discrete(name  ="Time points")+ theme_bw()+labs(title = "PCA plot of calb samples")+
  ggsave("./calb/calb_pca_ece1.png", units="in", width=6, heigh=4, dpi=300)


### Creating a supplementary xlsx file


res_calb_human_0_3D<-res_calb_human_0_3D_no_batch
res_calb_human_0_24e<-res_calb_human_0_24e_no_batch
res_calb_human_24_24e<-res_calb_human_24_24e_no_batch
res_calb_human_lrt<-res_lrt_human_calb
res_calb_lrt<-res_lrt_calb

wb_S6 <- createWorkbook("Supp_file_S6")

header<-c("gene", "baseMean","log2FoldChange","lfcSE","stat","pvalue","padj")
fungal_data_files<-c("res_calb_0_1.5",
                     "res_calb_0_3",
                     "res_calb_0_3c",
                     "res_calb_0_12",
                     "res_calb_0_24",
                     "res_calb_0_24c",
                     "res_calb_lrt",
                     "subset_0vs24",
                     "res_calb_0_vs_0e",
                     "res_calb_0e_vs_24e",
                     "res_calb_24e.c_vs_24e",
                     "res_calb_24_vs_24e",
                     "res_calb_0_vs_24e",
                     "res_calb_0e_vs_24e.c")


human_data_files<-c("res_calb_human_0_1.5",
                    "res_calb_human_0_3",
                    "res_calb_human_0_12",
                    "res_calb_human_0_24",
                    "res_calb_human_0_24c",
                    "res_calb_human_lrt",
                    "res_calb_human_0_3D",
                    "res_calb_human_0_24e",
                    "res_calb_human_24_24e")

file_names<-c(fungal_data_files,human_data_files)
descriptions<-c("C. albicans at 1.5 hpi compared to 0 h control",
                "C. albicans at 3 hpi compared to 0 h control",
                "C. albicans at 3 h control compared to 0 h control",
                "C. albicans at 12 hpi compared to 0 h control",
                "C. albicans at 24 hpi compared to 0 h control",
                "C. albicans at 24 h control compared to 0 h control",
                "LRT test for C. albicans samples (differential expression at any time point)",
                "Species-specific DE genes in C. albicans (DE exclusively during infection)",
                "C. albicans ece1 mutant at 0 h compared to 0 h control",
                "C. albicans ece1 mutant at 24 hpi compared to 0 h of C. albicans ece1 mutant",
                "C. albicans ece1 mutant at 24 hpi compared to 24 h control of C. albicans ece1 mutant",
                "C. albicans ece1 mutant at 24 hpi compared to C. albicans at 24 hpi",
                "C. albicans ece1 mutant at 24 hpi compared to 0 h control",
                "C. albicans ece1 mutant control at 24 h compared to C. albicans ece1 mutant at 0 h",
                "Human cells interacting with C. albicans at 1.5 hpi compared to 0 h control",
                "Human cells interacting with C. albicans at 3 hpi compared to 0 h control",
                "Human cells interacting with C. albicans at 12 hpi compared to 0 h control",
                "Human cells interacting with C. albicans at 24 hpi compared to 0 h control",
                "Human cells at 24 h control compared 0 h control",
                "LRT test of human cells interacting with C. albicans (differential expression at any time point)",
                "Human cells interacting with killed C. albicans at 3 hpi compared to 0 h control",
                "Human cells interacting with C. albicans ece1 mutant at 24 hpi compared to 0 h control",
                "Human cells interacting with C. albicans ece1 mutant at 24 hpi compared to 24 hpi with wild-type C. albicans"
)

sheets_and_descriptions<-cbind.data.frame("Data_sheets"=file_names,"Description"=descriptions)

addWorksheet(wb_S6,"Sheets_and_descriptions")
writeData(wb_S6, "Sheets_and_descriptions", sheets_and_descriptions,keepNA = T)

for (file in fungal_data_files){
  assign("fung",as.data.frame(eval(parse(text=paste0(file)))))
  fung <- cbind("genes"=rownames(fung), data.frame(fung, row.names=NULL))
  addWorksheet(wb_S6, file)
  writeData(wb_S6, file, fung,keepNA = T)
}

for (file in human_data_files){
  assign("hum",as.data.frame(eval(parse(text=paste0(file)))))
  hum<-hum[complete.cases(hum),]
  hum <- cbind("genes"=rownames(hum), data.frame(hum, row.names=NULL))
  addWorksheet(wb_S6, file)
  writeData(wb_S6, file, hum, keepNA = T)
}

saveWorkbook(wb_S6, "./calb/Supp_File_S6.xlsx", overwrite = TRUE)


### GO TERMS CALB.  One should create "fungi" directory in current directory.

### Finding MF,BP and CC terms
all_go_tems<-as.data.frame(GOTERM)

all_go_tems<-all_go_tems[!(all_go_tems$go_id %in% c("GO:0003674","GO:0008150","GO:0005575")),]


MF_terms<-all_go_tems$go_id[all_go_tems$Ontology=="MF"]
BP_terms<-all_go_tems$go_id[all_go_tems$Ontology=="BP"]
CC_terms<-all_go_tems$go_id[all_go_tems$Ontology=="CC"]


### Association of GOID with description
goterms <- Term(GOTERM)
a<-as.data.frame(goterms)
go_names<-cbind(row.names(a),a)


### CALB GOIDS
calb_go<-read.table("./calb_go.txt")


MF_universe<-calb_go[calb_go$V1 %in% MF_terms,]
BP_universe<-calb_go[calb_go$V1 %in% BP_terms,]
CC_universe<-calb_go[calb_go$V1 %in% CC_terms,]


fungal_goterms<-function(file,name,ont){
  ego<-enricher(file, pvalueCutoff = 0.05, 
                pAdjustMethod = "BH", universe = eval(parse(text=paste0(ont,"_universe$V2"))),minGSSize = 2, 
                maxGSSize = NA, TERM2GENE = eval(parse(text=paste0(ont,"_universe"))),TERM2NAME = go_names)
  if (!is.null(ego)){
    
    p<-dotplot(ego,showCategory = 30)
    p+ggplot2::ggsave(sprintf("./calb/fungi/%s_%s.png",name,ont),
                      units="in", width=10, heigh=7, dpi=600)
    write.table(ego,sprintf("./calb/fungi/%s_%s.txt",name,ont), sep = "\t")
    
  }
}


for (comp in fungal_data_files){
  for (ontology in c("BP","MF","CC")){
    data<- eval(parse(text = c(comp)))
    
    assign(paste0(comp,"_up"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange>1.5,]))
    assign(paste0(comp,"_down"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange< -1.5,]))
    
    fungal_goterms(eval(parse(text = paste0(comp,"_up"))),paste0(comp,"_up"),ontology)
    fungal_goterms(eval(parse(text = paste0(comp,"_down"))),paste0(comp,"_down"),ontology)
  }
}



### HUMAN GO TERMS. One should create "human" directory in current directory.


human_goterms<-function(file,name,ontology){
  ego<-enrichGO(file, 
                OrgDb = org.Hs.eg.db,
                keyType = "ENSEMBL",
                pvalueCutoff = 0.05, 
                pAdjustMethod = "BH",
                ont = ontology)
  if (!is.null(ego)){
    p<-dotplot(ego,showCategory = 30)
    p+ggplot2::ggsave(sprintf("./calb/human/%s_%s.png",name,ontology),
                      units="in", width=10, heigh=7, dpi=600)
    write.table(ego,sprintf("./calb/human/%s_%s.txt",name,ontology), sep = "\t")
    
  }
}


for (comp in human_data_files){
  for (ontology in c("BP","MF","CC")){
    data <- eval(parse(text = c(comp)))
    
    assign(paste0(comp,"_up"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange>1.5,]))
    assign(paste0(comp,"_down"),row.names(data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange< -1.5,]))
    
    human_goterms(eval(parse(text = paste0(comp,"_up"))),paste0(comp,"_up"),ontology)
    human_goterms(eval(parse(text = paste0(comp,"_down"))),paste0(comp,"_down"),ontology)
  }
}
