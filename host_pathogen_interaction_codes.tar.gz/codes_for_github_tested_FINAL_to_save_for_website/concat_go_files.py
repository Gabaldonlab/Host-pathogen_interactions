import os

all_go_terms=open("all_GO_tems.txt","w")

all_go_terms.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n"%("Species","Time_comparison","Up_or_Down_regulated","GO_category","GO_id","Description","Adj_p-value","Genes"))


with open("go_file_list.txt", "r+") as file_list:
    for f in file_list:
        f=f.rstrip()
        basename = os.path.splitext(os.path.basename(f))[0]
        ids=basename.split("_")
        if not "lrt" in ids:
            if "human" in ids:
                spp="human_"+ids[1]
            else:
                spp=ids[1]

            
            if not "inf" in ids:
				time=ids[-4]+"_vs_"+ids[-3]
            else:
				time=ids[-4]+"_"+ids[-3]
				
            direction=ids[-2]
            GO=ids[-1]
        else:
            if "human" in ids:
                spp="human_"+ids[1]
            else:
                spp=ids[1]

            time="lrt"
            direction=ids[-2]
            GO=ids[-1]
            
        with open(f,"r+") as go_file:
            next(go_file)
            for line in go_file:
                line=line.replace('"','')
                line=line.rstrip().split("\t")
                line=line
                #print(line)
                all_go_terms.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n"%(spp,time,direction,GO,line[1],line[2],line[6],line[8]))
all_go_terms.close()


