library(clusterProfiler)
library(GO.db)
library(WGCNA)
library(DESeq2)
library(org.Hs.eg.db)
library(tibble)
library(ggplot2)
library(ggpubr)


### Set the working directory to the downloaded folder.


### load all data


for (spp in c("calb","cglab","cpar","ctrop")){
  
  
  yeast<-read.table(sprintf("./%s_yeast_data.txt",spp),check.names = FALSE)
  
  human_controls<-read.table("calb_human_data.txt",check.names = FALSE)
  
  human<-read.table(sprintf("./%s_human_data.txt",spp),check.names = FALSE)
  
  if (!(spp=="calb")){
    
    human=cbind.data.frame(human_controls[,c(1,2)],human,human_controls[,c(23,24)])
  }
  
  
  shared_cols<-intersect(colnames(yeast),colnames(human))
  
  
  ### for analysing using counts and vst
  
  yeast_shared <- yeast[,shared_cols]
  human_shared <- human[,shared_cols]
  print(spp)
  
  if (!(spp=="calb")){
    
    human_shared<-cbind.data.frame(human_controls[,c(1,2)],human_shared,human_controls[,c(23,24)])
    
    if (spp=="ctrop"){
      
      yeast<-add_column(yeast, "45C+reseq" = yeast$`45C`+yeast$`45Creseq`, .after = "45")
      yeast$`45C`<-NULL
      yeast$`45Creseq`<-NULL
      
      yeast_shared<-cbind.data.frame(yeast[,c(1,2)],yeast_shared,yeast[,c(dim(yeast)[2]-1,dim(yeast)[2])])
    }
    
    else{
      yeast_shared<-cbind.data.frame(yeast[,c(1,2)],yeast_shared,yeast[,c(dim(yeast)[2]-1,dim(yeast)[2])])
    }
    
  }
  
  
  if (spp=="calb"){
    yeast_no_D<- subset(yeast_shared, select = -c(D1,D2,D3,e7,e8,e9))
    human_no_D<- subset(human_shared, select = -c(D1,D2,D3,e7,e8,e9))
  } else if (spp=="cglab"){
    yeast_no_D<- subset(yeast_shared, select = -c(D4,D5,D6))
    human_no_D<- subset(human_shared, select = -c(D4,D5,D6))
  } else if (spp=="cpar"){
    yeast_no_D<- subset(yeast_shared, select = -c(D7,D8,D9))
    human_no_D<- subset(human_shared, select = -c(D7,D8,D9))
  } else if (spp=="ctrop"){
    yeast_no_D<- subset(yeast_shared, select = -c(D10,D11,D12))
    human_no_D<- subset(human_shared, select = -c(D10,D11,D12))
  }
  
  colnames(yeast_no_D)[c(1,2,dim(yeast_no_D)[2]-1,dim(yeast_no_D)[2])]<-c("1","2","17","18")
  counts_merged<-rbind.data.frame(yeast_no_D,human_no_D)
  assign(paste0(spp,"_counts_merged"),counts_merged)
  
  
  
  yeast_no_D_filt<-yeast_no_D[rowSums(yeast_no_D >= 10) >= 0.9*ncol(yeast_no_D),]  
  human_no_D_filt<-human_no_D[rowSums(human_no_D >= 10) >= 0.9*ncol(human_no_D),]  
  
  
  ### fake model to generate vst-transformated counts (transformatio does not depend on model)
  colData_yeast<-data.frame(a=c(rep("a",length(colnames(yeast_no_D_filt))-2),rep("b",2)))
  pre_dds_yeast <- DESeqDataSetFromMatrix(yeast_no_D_filt, colData=colData_yeast,~a)
  dds_counts_yeast <- DESeq(pre_dds_yeast)
  counts_norm_yeast<-vst(dds_counts_yeast,blind = T)
  vst_yeast<-assay(counts_norm_yeast)
  
  
  colData_human<-data.frame(a=c(rep("a",length(colnames(human_no_D_filt))-2),rep("b",2)))
  pre_dds_human <- DESeqDataSetFromMatrix(human_no_D_filt, colData=colData_human,~a)
  dds_counts_human <- DESeq(pre_dds_human)
  counts_norm_human<-vst(dds_counts_human,blind = T)
  vst_human<-assay(counts_norm_human)
  
  
  all_vst<-rbind.data.frame(vst_yeast,vst_human)
  assign(paste0(spp,"_vst"),all_vst)
}


###### Choose Soft thresholds


choose_soft_threshold_and_plot_results<-function(TPM_table,spp){
  powers = c(c(1:10), seq(from = 12, to=30, by=2))
  
  
  sft_spp = pickSoftThreshold(t(TPM_table), powerVector = powers, verbose = 5, networkType = "unsigned")
  
  # Scale-free topology fit index as a function of the soft-thresholding power
  scale_plot<-ggplot(sft_spp$fitIndices,aes(sft_spp$fitIndices[,1], -sign(sft_spp$fitIndices[,3])*sft_spp$fitIndices[,2]))+
    geom_point(size=2)+geom_text(label=sft_spp$fitIndices$Power,hjust=0.5, vjust=-1, size=6)+geom_hline(yintercept = 0.8, color="red")+
    xlab("Soft Threshold (power)\n")+ylab("\n\nScale Free Topology Model Fit,unsigned R^2")+theme_bw()+
    ggtitle(paste0("Soft thresholds for human + ",spp))+
    theme(plot.title = element_text(hjust = 0.5,size = 16),
          axis.text = element_text(size = 14),axis.title = element_text(size=14))+
    scale_y_continuous(breaks=seq(-1, 1.1, 0.2))+expand_limits(y=c(-1,1.1))
  
  assign(paste0(spp,"_scale_plot"),scale_plot,envir = .GlobalEnv)
  
}



choose_soft_threshold_and_plot_results(calb_vst,"calb")
choose_soft_threshold_and_plot_results(cglab_vst,"cglab")
choose_soft_threshold_and_plot_results(cpar_vst,"cpar")
choose_soft_threshold_and_plot_results(ctrop_vst,"ctrop") 


ggarrange(ggarrange(calb_scale_plot, cglab_scale_plot, ncol = 2, labels = c("a", "b"), align = "h",font.label = list(size = 20, color = "black")), 
          ggarrange(cpar_scale_plot, ctrop_scale_plot, ncol = 2, labels = c("c", "d"), align = "h",font.label = list(size = 20, color = "black")), 
          nrow = 2)+
  ggsave("./soft_thresholds.png",units="in", width=16, heigh=10, dpi=300)


############ Building network and modules

build_network_and_modules<-function(TPM_table,spp,soft_threshold){
  
  #### calculate adjacency, TOM, cluster tree and plot
  adjacency = adjacency(t(TPM_table), power = soft_threshold,type = "unsigned")
  TOM = TOMsimilarity(adjacency,TOMType = "unsigned")
  
  dissTOM = 1-TOM
  geneTree = hclust(as.dist(dissTOM), method = "average")
  
  ###### Find modules
  dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM,deepSplit = 2,
                              pamRespectsDendro = FALSE,minClusterSize = 30)
  table(dynamicMods)
  
  #Plot module assignment
  dynamicColors = labels2colors(dynamicMods)
  table(dynamicColors)
  
  
  ### Merge similar modules
  
  # Calculate eigengenes
  MEList = moduleEigengenes(t(TPM_table), colors = dynamicColors,subHubs=TRUE,excludeGrey = T)
  MEs = MEList$eigengenes
  
  # Calculate dissimilarity of module eigengenes
  MEDiss = 1-cor(MEs)
  
  # Cluster module eigengenes
  METree = hclust(as.dist(MEDiss), method = "average")
  
  #Plot the cut line into the dendrogram
  MEDissThres = 0.25
  #abline(h=MEDissThres, col = "red")
  
  # Call an automatic merging function
  merge = mergeCloseModules(t(TPM_table), dynamicColors, cutHeight = MEDissThres, verbose = 3)
  
  # The merged module colors
  mergedColors = merge$colors
  
  # Eigengenes of the new merged modules:
  mergedMEs = merge$newMEs
  png(sprintf("./%s_modules_vst.png",spp),units = "in",width = 12,height = 5, res = 600)
  plotDendroAndColors(geneTree, cbind(dynamicColors, mergedColors),
                      c("Gene\nclustering", sprintf("Eigengene\nclustering")),
                      dendroLabels = FALSE, hang = 0.03,
                      addGuide = TRUE, guideHang = 0.05, main=sprintf("Cluster Dendrogram (%s)", spp))
  dev.off()
  
  # Rename to moduleColors
  moduleColors = mergedColors
  moduleColors<<-moduleColors
  # Construct numerical labels corresponding to the colors
  colorOrder = c("grey", standardColors(50))
  moduleLabels = match(moduleColors, colorOrder)-1
  MEs = mergedMEs
  
  ### Selecting hub genes
  
  top_hubs<-chooseTopHubInEachModule(t(TPM_table), colorh=moduleColors, power = soft_threshold ,type = "unsigned")
  
  assign(paste0(spp,"_top_hubs"),top_hubs,envir = .GlobalEnv)
  
  
  ### Connectivity
  
  iK=intramodularConnectivity.fromExpr(t(TPM_table), power=soft_threshold, colors=moduleColors,networkType = "unsigned" )
  row.names(iK)=row.names(TPM_table)
  
  assign(paste0(spp,"_connectivity"),iK,envir = .GlobalEnv)
  
  ### count number of fungal genes in modules
  module_stats<-NULL
  all_fung_genes_in_modules<-NULL
  all_fung_genes_in_modules_id_module<-NULL
  n=0
  for (module in unique(moduleColors)){
    if(!(module=="grey")){
      print(module)
      n=n+1
      ## names is the same as colnames.
      gene_ids<-names(as.data.frame((t(TPM_table))))[moduleColors==module]
      module_stats<-rbind(module_stats,
                          c(module,paste0("module",n),
                            as.numeric(length(gene_ids)),
                            as.numeric(length(gene_ids[!grepl("ENSG", gene_ids)])),
                            round(as.numeric(length(gene_ids[!grepl("ENSG", gene_ids)]))/as.numeric(length(gene_ids))*100,2),
                            as.numeric(length(gene_ids[grepl("ENSG", gene_ids)])),
                            round(as.numeric(length(gene_ids[grepl("ENSG", gene_ids)]))/as.numeric(length(gene_ids))*100,2),spp))
      all_fung_genes_in_modules<-c(all_fung_genes_in_modules,gene_ids[!grepl("ENSG", gene_ids)])
      
      if (length(gene_ids[!grepl("ENSG", gene_ids)])>0){
        all_fung_genes_in_modules_id_module<-rbind.data.frame(all_fung_genes_in_modules_id_module,cbind.data.frame(gene_ids[!grepl("ENSG", gene_ids)],paste0("module",n)))
      }
      
    }
  }
  all_fung_genes_in_modules_unique<-unique(all_fung_genes_in_modules)
  assign(paste0(spp,"_all_fung_genes_in_modules"),all_fung_genes_in_modules_unique, envir = .GlobalEnv)
  colnames(all_fung_genes_in_modules_id_module)<-c("gene","module")
  assign(paste0(spp,"_all_fung_genes_in_modules_id_module"),all_fung_genes_in_modules_id_module, envir = .GlobalEnv)
  
  ##### GO TERMS
  
  ### Association of GOID with description
  goterms <- Term(GOTERM)
  a<-as.data.frame(goterms)
  go_names<<-cbind(row.names(a),a)
  
  
  ### Yeast GOIDS
  yeast_go<<-read.table(sprintf("./%s_go.txt",spp))
  
  
  MF_universe<<-yeast_go[yeast_go$V3 =="F",][,c(1,2)]
  BP_universe<<-yeast_go[yeast_go$V3 =="P",][,c(1,2)]
  CC_universe<<-yeast_go[yeast_go$V3 =="C",][,c(1,2)]
  
  
  module_go_terms<-NULL
  module_go_terms_h<-NULL
  
  for (module in unique(moduleColors)){
    if (!(module=="grey")){
      
      ## names is the same as colnames.
      gene_ids<-names(as.data.frame((t(TPM_table))))[moduleColors==module]
      
      gene_ids_human<<-gene_ids[grepl("ENS",gene_ids)]
      
      gene_ids_yeast<<-gene_ids[!grepl("ENS",gene_ids)]
      
      print(c(module,length(gene_ids),length(gene_ids_human),length(gene_ids_yeast)))
      
      
      print(module)
      for (ontology in c("MF","CC","BP")){
        ego<<-enricher(gene_ids_yeast, pvalueCutoff = 0.05,
                       pAdjustMethod = "BH", universe = eval(parse(text=paste0("as.character(",ontology,"_universe$V2)"))),
                       minGSSize = 5,maxGSSize = 10000, TERM2GENE = eval(parse(text=paste0(ontology,"_universe"))),TERM2NAME = go_names)
        ego_h<<- enrichGO(gene_ids_human,
                          OrgDb = org.Hs.eg.db,
                          keyType = "ENSEMBL",
                          pvalueCutoff = 0.05,
                          pAdjustMethod = "BH",
                          ont = ontology)
        
        if (!is.null(ego)){
          
          # yeast
          p<-dotplot(ego,showCategory = 5)
          p+ggplot2::ggsave(sprintf("./%s/coexpression/%s_module_%s_%s.png",spp,spp,module,ontology),
                            units="in", width=10, height =7, dpi=600)
          write.table(ego,sprintf("./%s/coexpression/%s_module_%s_%s.txt",spp,spp,module,ontology), sep = "\t")
          
          assign(sprintf("%s_module_%s_%s.txt",spp,module,ontology),as.data.frame(ego), envir = .GlobalEnv)
          
          
        }
        
        
        if (!is.null(ego_h)){
          
          # human
          ph<-dotplot(ego_h,showCategory = 5)
          ph+ggplot2::ggsave(sprintf("./%s/coexpression/%s_human_module_%s_%s.png",spp,spp,module,ontology),
                             units="in", width=10, height =7, dpi=600)
          write.table(ego_h,sprintf("./%s/coexpression/%s_human_module_%s_%s.txt",spp,spp,module,ontology), sep = "\t")
          
          assign(sprintf("%s_human_module_%s_%s.txt",spp,module,ontology),as.data.frame(ego_h), envir = .GlobalEnv)
        }
        
        ### for yeast
        if (ontology=="BP"){
          if (dim(as.data.frame(ego))[1]==0){
            
            module_go_terms<-rbind.data.frame(module_go_terms,cbind("NA",module,toString(gene_ids_yeast)))
          }
          else if (length(gene_ids_yeast)<2){
            
            module_go_terms<-rbind.data.frame(module_go_terms,cbind("NA",module,toString(gene_ids_yeast)))
          }
          
          else if (dim(ego)[1]<3){
            
            module_go_terms<-rbind.data.frame(module_go_terms,cbind(toString(as.character(ego[,2])),module,toString(gene_ids_yeast)))
          }
          
          else {
            
            module_go_terms<-rbind.data.frame(module_go_terms,cbind(toString(as.character(ego[c(1:3),2])),module,toString(gene_ids_yeast)))
            
          }
          
        }
        
        ### for human
        if (ontology=="BP"){
          if (dim(as.data.frame(ego_h))[1]==0){
            
            module_go_terms_h<-rbind.data.frame(module_go_terms_h,cbind("NA",module,toString(gene_ids_human)))
          }
          else if (length(gene_ids_human)<2){
            
            module_go_terms_h<-rbind.data.frame(module_go_terms_h,cbind("NA",module,toString(gene_ids_human)))
          }
          
          else if (dim(ego_h)[1]<3){
            
            module_go_terms_h<-rbind.data.frame(module_go_terms_h,cbind(toString(as.character(ego_h[,2])),module,toString(gene_ids_human)))
          }
          
          else{
            module_go_terms_h<-rbind.data.frame(module_go_terms_h,cbind(toString(as.character(ego_h[c(1:3),2])),module,toString(gene_ids_human)))
            
            
          }
          
          
        }
      }
    }
  }
  
  
  module_go_terms_out<<-module_go_terms
  module_go_terms_h_out<<-module_go_terms_h
  colnames(module_go_terms)<-c("GO_terms_yeast","Module_color","Gene_IDs_yeast")
  colnames(module_go_terms_h)<-c("GO_terms_human","Module_color","Gene_IDs_human")
  
  
  colnames(module_stats)<-c("Module_color","Module","N_genes","N_genes_yeast","prcnt_yeast_genes","N_genes_human","prcnt_human_genes","Spp")
  
  module_go_terms<-cbind.data.frame(module_go_terms,module_go_terms_h[,c(1,3)])
  
  module_stats<-as.data.frame(module_stats)
  module_stats_sort<-merge(module_stats,module_go_terms, by=c("Module_color"))
  
  module_stats_sort_final <- module_stats_sort[order(as.numeric(as.character(module_stats_sort$N_genes)),decreasing = F),]
  
  
  assign(paste0(spp,"_module_stats_sort_final"),module_stats_sort_final, envir = .GlobalEnv)
  
  ### These plots are not reported in the paper
  ### plots without GO terms
  # ggplot(data=module_stats_sort_final, aes(x=Module,y=as.numeric(as.character(N_genes)),width=0.9, fill=Module,
  #                                          label = paste0(module_stats_sort_final$N_yeast_genes,"(",module_stats_sort_final$prcnt_yeast_genes,"%)"))) +
  #   geom_bar(stat="identity")+scale_fill_manual(values = as.character(module_stats_sort_final$Module))+
  #   geom_text(hjust=0, size=5)+theme_bw()+coord_flip()+
  #   ylab("Number of genes in modules")+xlab(sprintf("Modules (%s)",spp))+
  #   theme(legend.position = "none",
  #         axis.text = element_text(size = 18),axis.title = element_text(size=18),
  #         axis.text.y = element_blank(),
  #         axis.ticks.y = element_blank(),
  #         axis.text.x = element_text(angle = 90,vjust=0.5, hjust=1),
  #         plot.title = element_text(hjust = 0.5))+
  #   scale_y_continuous(breaks=seq(0, max(as.numeric(as.character(module_stats_sort_final$N_genes)))+300, 200))+
  #   expand_limits(y=c(0, max(as.numeric(as.character(module_stats_sort_final$N_genes)))+300))+
  #   scale_x_discrete(labels=as.character(module_stats_sort_final$Module))+
  #   ggsave(sprintf("./%s/coexpression/%s_N_genes_in_modules.png",spp,spp), width = 12, height = 6,dpi = 300)
  
  ### plots with GO terms
  # ggplot(data=module_stats_sort_final, aes(x=Module,y=as.numeric(as.character(N_genes)),width=0.9, fill=Module,
  #                                          label = paste0(module_stats_sort_final$N_fung_genes,"(",module_stats_sort_final$prcnt_fung_genes,"%)"))) +
  #   geom_bar(stat="identity")+scale_fill_manual(values = as.character(module_stats_sort_final$Module))+
  #   geom_text(hjust=0, size=4)+theme_bw()+coord_flip()+
  #   ylab("Number of genes in modules")+ggtitle(sprintf("Modules (%s)",spp))+xlab(NULL)+
  #   theme(legend.position = "none",
  #         axis.text = element_text(size = 12),axis.title = element_text(size=12),
  #         axis.text.x = element_text(angle = 90,vjust=0.5, hjust=1),
  #         plot.title = element_text(hjust = 0.5))+
  #   scale_y_continuous(breaks=seq(0, max(as.numeric(as.character(module_stats_sort_final$N_genes)))+300, 200))+
  #   expand_limits(y=c(0, max(as.numeric(as.character(module_stats_sort_final$N_genes)))+300))+
  #   scale_x_discrete(labels=as.character(module_stats_sort_final$GO_terms))+
  #   ggsave(sprintf("./%s/coexpression/%s_N_genes_in_modules_with_GO.png",spp,spp), width = 12, height = 6,dpi = 300)
  
}

build_network_and_modules(calb_vst,"calb",12)
build_network_and_modules(cglab_vst,"cglab",20)
build_network_and_modules(cpar_vst,"cpar",7)
build_network_and_modules(ctrop_vst,"ctrop",22)

all_go_terms_for_modules<-rbind.data.frame(calb_module_stats_sort_final,
                                           ctrop_module_stats_sort_final,
                                           cpar_module_stats_sort_final,
                                           cglab_module_stats_sort_final)



all_go_terms_for_modules_final<-all_go_terms_for_modules[,c[-1]]
all_go_terms_for_modules_final<-remove.factors(all_go_terms_for_modules_final)
## Libraries are loaded here to avoid conlicts with ClusterProfiler
library(taRifx)
library(dplyr)
library(tidyr)
library(openxlsx)

wb_S10 <- createWorkbook("Supp_File_S10.xlsx")
addWorksheet(wb_S10, "all_go_terms_for_modules")
writeData(wb_S10, "all_go_terms_for_modules", all_go_terms_for_modules_final,keepNA = T)
saveWorkbook(wb_S10, "./Supp_File_S10.xlsx", overwrite = TRUE)



### import ortholog table

orthologs<-read.table("./orthologs.txt", sep="\t", header = TRUE)
colnames(orthologs)<-c("calb","calb_orf","ctrop","ctrop_gene","cpar","cglab")
orthologs$ctrop<-gsub("\\.1","",orthologs$ctrop)   ### remove .1 from CTROP gene ids, same as above



compare_modules<-function(comparison,spp,ref,other_spp){
  
  ref_modules<-unique(as.character(ref$module))
  
  percent_data<-NULL
  
  for (module in ref_modules){
    
    
    
    module_genes<-as.character(ref[
      as.character(ref$module)==module,][,1])
    
    if(length(module_genes)==0) next 
    
    
    spp3=other_spp
    
    for (spp2 in spp3){
      
      modules<-unique(as.character(eval(parse(text=paste0(spp2,"_all_fung_genes_in_modules_id_module$module")))))
      
      for (module_2 in modules){
        df<-eval(parse(text=paste0(spp2,"_all_fung_genes_in_modules_id_module")))
        
        module_2_genes<-as.character(df[
          as.character(df$module)==module_2,][,1])
        
        module_genes_orth_df<-orthologs[eval(parse(text=paste0("orthologs$",spp))) %in% module_genes,] ### equivalent to # pre_cpar_orth<-orthologs[orthologs$CPAR %in%  DEG_cpar,]
        
        module_genes_orth<-as.vector(eval(parse(text=paste0("module_genes_orth_df$",spp))))   ### equivalent to # cpar_orth<-as.vector(pre_cpar_orth$CALB)
        
        assign(paste0("pre_",spp2,"_orth"),orthologs[eval(parse(text=paste0("orthologs$",spp2))) %in% module_2_genes,]) ### equivalent to # pre_cpar_orth<-orthologs[orthologs$CPAR %in%  DEG_cpar,]
        orth<-as.vector(eval(parse(text=paste0("pre_",spp2,"_orth$",spp))))   ### equivalent to # cpar_orth<-as.vector(pre_cpar_orth$CALB)
        
        
        percent<-length(intersect(module_genes_orth,orth))/length(union(module_genes_orth,orth))*100
        
        percent_data<-rbind.data.frame(percent_data,cbind(spp,module,spp2,module_2,paste0(spp2,"_",module_2),as.numeric(percent)))
      }    
    }
  }
  print(percent_data)
  percent_data<-remove.factors(percent_data)
  
  colnames(percent_data)<-c("ref","ref_module","spp","spp_module","id","percent")
  assign(paste0(comparison,"_percent"),percent_data,envir = .GlobalEnv)
  
  percent_data %>% group_by(ref_module,spp) %>%slice(which.max(percent))->>to_plot
  
  to_plot<-as.data.frame(to_plot)
  order<-c()
  for (i in c(1:length(unique(to_plot$ref_module)))){
    #print(i)
    order<-c(order,paste0("module",i))
  }
  
  assign(paste0(spp,"_to_plot"),to_plot,envir = .GlobalEnv)
  
  #to_plot<<-to_plot %>% group_by(ref_module) %>% top_n(1, percent)
  
  to_plot$ref_module<-factor(to_plot$ref_module, levels = order)
  
  p<-ggplot(to_plot, aes(x=id, y=as.numeric(to_plot$percent)))+geom_bar(stat = "identity")+ylim(0,100)+facet_grid(ref_module ~ .,scales = "free")+
    coord_flip()+ylab("% similarity")+xlab("<spp>_<module>")+theme_bw()+
    theme(strip.text = element_text(size = 13, face = "bold"),
          text = element_text(size=18))+
    geom_text(aes(label=round(as.numeric(to_plot$percent),1)), hjust=0)
  
  
  
  assign(paste0("p_",spp),p, envir = .GlobalEnv)
}


compare_modules("calb_vs_rest","calb",calb_all_fung_genes_in_modules_id_module,c("cglab","cpar","ctrop"))
compare_modules("cglab_vs_rest","cglab",cglab_all_fung_genes_in_modules_id_module,c("calb","cpar","ctrop"))
compare_modules("cpar_vs_rest","cpar",cpar_all_fung_genes_in_modules_id_module,c("cglab","calb","ctrop"))
compare_modules("ctrop_vs_rest","ctrop",ctrop_all_fung_genes_in_modules_id_module,c("calb","cpar","cglab"))



ggarrange(p_calb,p_cglab,p_cpar,p_ctrop,ncol = 4, nrow = 1,
          labels = c("a", "b","c","d"),font.label = list(size = 18, color = "black"))+
  ggsave("./Supp_Fig_S3.png", height = 26.5, width = 16,units = "in")

summary(as.numeric(rbind(calb_to_plot,cglab_to_plot,cpar_to_plot,ctrop_to_plot)[,6]))
