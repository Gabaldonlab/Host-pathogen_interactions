library(gplots)
library(RColorBrewer)
library(reshape)
library(ggplot2)
library(ggrepel)
library(DESeq2)
library(tibble)   ### for inserting columns in dataframe
library(gplots)
library(pheatmap)
library(VennDiagram)
library(stringr)
library(EDASeq)
library(RUVSeq)
library(clusterProfiler)
library(org.Hs.eg.db)
library(dplyr)
library(tidyr)


### First, run the scripts for each species. Then in this script set the working direcorty to the downloaded folder.

#########################################
################# HUMAN #################
#########################################


for (specie in c("calb","cglab","cpar","ctrop")){
  data<-read.table(paste0(specie,"/res_lrt_human_",specie,".txt"))
  assign(paste0("human_",specie,"_rlt_no_DE"),data[!is.na(data$padj) & data$padj>0.05 & data$baseMean>10,]) 
}

overlap_for_batch<-as.data.frame(Reduce(intersect,list(rownames(human_calb_rlt_no_DE),
                                              rownames(human_cglab_rlt_no_DE),
                                              rownames(human_cpar_rlt_no_DE),
                                              rownames(human_ctrop_rlt_no_DE))))
colnames(overlap_for_batch)<-"genes"


#### Venn diagrams for each time point
human_venn_each_time_point<-function(sign,lfc){
  for (timepoint in c("3","12","24")){
    for (specie in c("calb","cglab","cpar","ctrop")){
      data<-read.table(file=sprintf("./%s/res_human_%s_0_vs_%s.txt",specie,specie,timepoint)) 
      DEG<-rownames(data[!is.na(data$padj) & data$padj<0.01 & eval(parse(text=paste0("data$log2FoldChange",sign," ",lfc))),])
      assign(paste0("DEG_",specie),DEG)
    }
    venn.diagram(list("DEG in C. alb."=DEG_calb,
                      "DEG in C. par."=DEG_cpar,
                      "DEG in C. trop."=DEG_ctrop,
                      "DEG in C. glab."=DEG_cglab),
                 fill=c("red", "blue", "green", "orange"), height = 2500, width = 2500, resolution = 600, 
                 main = paste0("Human response 4 spp. at ",timepoint,"h\n (p<0.01, L2FC",sign,lfc,")"), cat.cex=0.4, cex=2.1, main.cex = 0.7, 
                 filename=paste0("./all_spp_comparisons/human_venn_",timepoint,"_L2FC",sign,lfc,".png"),  
                 imagetype = "png")
    }
}

human_venn_each_time_point(">",0)   
human_venn_each_time_point(">",1.5)
human_venn_each_time_point("<",0)
human_venn_each_time_point("<",-1.5)

#### Making a PCA for human data

human_with_e_and_D_calb<-read.table("./calb_human_data.txt",check.names = FALSE)
human_with_e_and_D_cglab<-read.table("./cglab_human_data.txt",check.names = FALSE)
human_with_e_and_D_cpar<-read.table("./cpar_human_data.txt",check.names = FALSE)
human_with_e_and_D_ctrop<-read.table("./ctrop_human_data.txt",check.names = FALSE)

all_human_data<-cbind.data.frame(human_with_e_and_D_calb,human_with_e_and_D_cglab,human_with_e_and_D_cpar,human_with_e_and_D_ctrop)

#### collapsing technical replicates
all_human_data<-add_column(all_human_data, "3+reseq" = all_human_data$`3`+all_human_data$`3reseq`, .after = "2")
all_human_data$`3reseq`<-NULL
all_human_data$`3`<-NULL

all_human_data<-add_column(all_human_data, "24+reseq" = all_human_data$`24`+all_human_data$`24reseq`, .after = "D6")
all_human_data$`24reseq`<-NULL
all_human_data$`24`<-NULL

all_human_data<-add_column(all_human_data, "36+reseq" = all_human_data$`36`+all_human_data$`36reseq`, .after = "35")
all_human_data$`36reseq`<-NULL
all_human_data$`36`<-NULL

all_human_data<-add_column(all_human_data, "37+reseq" = all_human_data$`37`+all_human_data$`37reseq`, .after = "D9")
all_human_data$`37reseq`<-NULL
all_human_data$`37`<-NULL

all_human_data<-add_column(all_human_data, "52+2reseq" = all_human_data$`52`+all_human_data$`52reseq`+all_human_data$`52reseq2`, .after = "51")
all_human_data$`52reseq`<-NULL
all_human_data$`52reseq2`<-NULL
all_human_data$`52`<-NULL

all_human_data<-add_column(all_human_data, "53+reseq" = all_human_data$`53`+all_human_data$`53reseq`, .after = "52+2reseq")
all_human_data$`53reseq`<-NULL
all_human_data$`53`<-NULL


### no batch correction

myColors <- brewer.pal(8,"Dark2")
names(myColors) <- c("0_control","1.5","3","3_dead","12","24","24_control","24_ece1")
colScale <- scale_colour_manual(name = "Time point (h)",values = myColors)

### Comment below to exclude 1.5h
# all_human_data_to_plot<-all_human_data
# myColors <- brewer.pal(8,"Dark2")
# names(myColors) <- c("0_control","1.5","3","3_dead","12","24","24_control","24_ece1")
# colScale <- scale_colour_manual(name = "Time point (h)",values = myColors)
# 
# 
# species<-c(rep("control",2),rep("calb",19), rep("control",2),rep("cglab",12),rep("cpar",12),rep("ctrop",12))
# time_point<-c(c("0_control","0_control","1.5","1.5","1.5","3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24","24","24_ece1","24_ece1","24_ece1","24_control","24_control"),     ## calb
#               c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cglab
#               c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cpar
#               c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"))  ### ctrop
####

### Uncomment below to exclude 1.5h
all_human_data_to_plot<-all_human_data[,-c(3,4,5)]
species<-c(rep("control",2),rep("calb",16), rep("control",2),rep("cglab",12),rep("cpar",12),rep("ctrop",12))
time_point<-c(c("0_control","0_control","3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24","24","24_ece1","24_ece1","24_ece1","24_control","24_control"),     ## calb
              c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cglab
              c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cpar
              c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"))  ### ctrop
####

colData<-data.frame(species=species, time_point=time_point)
pre_dds <- DESeqDataSetFromMatrix(all_human_data_to_plot, colData=colData,~time_point)
dds_human <- DESeq(pre_dds)
all_data_norm<-vst(dds_human)
vst_data<-assay(all_data_norm)
pca <- prcomp(t(vst_data))

percentVar <- pca$sdev^2/sum(pca$sdev^2)

df_plotting<-data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2],colData) ### do PC2 = pca$x[, 2]*-1 to invert values

### Comment below to exlude 1.5h
#df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","1.5","3","3_dead","12","24","24_ece1","24_control"))


### Uncomment below to exlude 1.5h
df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","3","3_dead","12","24","24_ece1","24_control"))


ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=time_point, shape=species), size=6)+
  geom_text_repel(label=as.character(rownames(df_plotting)), size = 4, segment.color = "black",arrow = arrow(length = unit(0, 'npc')))+
  xlab(paste0("PC1: ",round(percentVar[1]*100),"% variance")) +
  ylab(paste0("PC2: ",round(percentVar[2]*100),"% variance")) +
  coord_fixed()+ theme_bw()+colScale+
  guides(colour = guide_legend(order = 1),
         size = guide_legend(order = 2))+
  labs(shape="Species", colour="Time point")+
  theme(axis.text = element_text(size = 16),axis.title = element_text(size=16),
        legend.text = element_text(size=14),legend.title = element_text(size=14))+
  ggsave("./all_spp_comparisons/human_pca_all_genes_with_ece1_and_dead_k0_no_1.5.png", units="in", width=10, heigh=7, dpi=600)



##### PCA with RUVg batch effect removal
deseq2_human <- function(cond) {
  myColors <- brewer.pal(8,"Dark2")
  names(myColors) <- c("0_control","1.5","3","3_dead","12","24","24_control","24_ece1")
  colScale <- scale_colour_manual(name = "Time point (h)",values = myColors)


  if (cond == c("with dead and ece1")){
    ## uncomment below to exclude 1.5 h samples
    all_human_data<-all_human_data[,-c(3,4,5)]
    
    
    species<-c(rep("control",2),rep("calb",16), rep("control",2),rep("cglab",12),rep("cpar",12),rep("ctrop",12))
    time_point<-c(c("0_control","0_control","3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24","24","24_ece1","24_ece1","24_ece1","24_control","24_control"),     ## calb
                  c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cglab
                  c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cpar
                  c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"))  ### ctrop
    batch<-c(rep("1",5),rep("2",3),rep("1",7),rep("2",3),rep("1",2),
             rep("1",3),rep("2",3),rep("1",6),
             rep("1",3),rep("2",3),rep("1",6),
             rep("1",3),rep("2",3),rep("1",6))
  ######
  
  ## comment below to exlcude 1.5 h samples
  # if (cond == c("with dead and ece1")){
  # 
  #   species<-c(rep("control",2),rep("calb",19), rep("control",2),rep("cglab",12),rep("cpar",12),rep("ctrop",12))
  #   time_point<-c(c("0_control","0_control","1.5","1.5","1.5","3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24","24","24_ece1","24_ece1","24_ece1","24_control","24_control"),     ## calb
  #                 c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cglab
  #                 c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"),   ### cpar
  #                 c("3","3","3","3_dead","3_dead","3_dead","12","12","12","24","24","24"))  ### ctrop
  #   batch<-c(rep("1",8),rep("2",3),rep("1",7),rep("2",3),rep("1",2),
  #            rep("1",3),rep("2",3),rep("1",6),
  #            rep("1",3),rep("2",3),rep("1",6),
  #            rep("1",3),rep("2",3),rep("1",6))
    
    
    #######
    
    colData<-data.frame(batch=batch)
    
    set_to_remove_batch <- newSeqExpressionSet(as.matrix(all_human_data),phenoData = as.data.frame(colData, row.names=colnames(all_human_data)))
    
    removed_batch_effect <<- RUVg(set_to_remove_batch, as.character(overlap_for_batch$genes), k=3)
    pData(removed_batch_effect)
    
    pre_dds_no_batch <- DESeqDataSetFromMatrix(countData = normCounts(removed_batch_effect),colData = pData(removed_batch_effect), design = ~W_1+W_2+W_3+batch)

    dds_no_batch<-DESeq(pre_dds_no_batch)
    
    
    all_data_nobatch_norm<-vst(dds_no_batch,blind = T)
    vst_data_no_batch<-assay(all_data_nobatch_norm)
    pca <- prcomp(t(vst_data_no_batch))
    percentVar <- pca$sdev^2/sum(pca$sdev^2)
    
    colData_mod<-data.frame(species=species, time_point=time_point, batch_effect=batch)
    df_plotting<-data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2]*-1,colData_mod) ### do PC2 = pca$x[, 2]*-1 to invert values
    
    ## comment below to exclude 1.5 h samples
    #df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","1.5","3","3_dead","12","24","24_ece1","24_control"))
    
    
    ## Uncomment below to exclude 1.5 h samples
    df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","3","3_dead","12","24","24_ece1","24_control"))
    
    ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=time_point, shape=species), size=6)+
      geom_text_repel(label=as.character(rownames(df_plotting)), size = 4, segment.color = "black",arrow = arrow(length = unit(0, 'npc')))+
      xlab(paste0("PC1: ",round(percentVar[1]*100),"% variance")) +
      ylab(paste0("PC2: ",round(percentVar[2]*100),"% variance")) +
      coord_fixed()+ theme_bw()+colScale+
      guides(colour = guide_legend(order = 1),
             size = guide_legend(order = 2))+
      labs(shape="Species", colour="Time point")+
      theme(axis.text = element_text(size = 16),axis.title = element_text(size=16),
            legend.text = element_text(size=14),legend.title = element_text(size=14))+
       ggsave("./all_spp_comparisons/human_pca_all_genes_with_ece1_and_dead_no_batch_k3_inverted_no_1.5.png", units="in", width=10, heigh=7, dpi=600)
    
    }
  
  else{
    
    
    ## uncomment below to exclude 1.5 h samples
    all_human_data<-all_human_data[,-c(3,4,5,9,10,11,19,20,21,27,28,29,39,40,41,51,52,53)]


    species<-c(rep("control",2),rep("calb",10), rep("control",2),rep("cglab",9),rep("cpar",9),rep("ctrop",9))
    time_point<-c(c("0_control","0_control","3","3","3","12","12","12","24","24","24","24","24_control","24_control"),     ## calb
                    c("3","3","3","12","12","12","24","24","24"),   ### cglab
                    c("3","3","3","12","12","12","24","24","24"),   ### cpar
                    c("3","3","3","12","12","12","24","24","24"))  ### ctrop

    ######
    
    ## Comment below to exclude 1.5 h samples
    # all_human_data<-all_human_data[,-c(9,10,11,19,20,21,27,28,29,39,40,41,51,52,53)]
    # 
    # species<-c(rep("control",2),rep("calb",13), rep("control",2),rep("cglab",9),rep("cpar",9),rep("ctrop",9))
    # time_point<-c(c("0_control","0_control","1.5","1.5","1.5","3","3","3","12","12","12","24","24","24","24","24_control","24_control"),     ## calb
    #               c("3","3","3","12","12","12","24","24","24"),   ### cglab
    #               c("3","3","3","12","12","12","24","24","24"),   ### cpar
    #               c("3","3","3","12","12","12","24","24","24"))  ### ctrop
    # 
    ###
    
    colData<-data.frame(species=species, time_point=time_point)
    pre_dds <- DESeqDataSetFromMatrix(all_human_data, colData=colData,~time_point)
    dds_human <- DESeq(pre_dds)
    all_data_norm<-vst(dds_human)
    vst_data<-assay(all_data_norm)
    pca <- prcomp(t(vst_data))
    
    percentVar <- pca$sdev^2/sum(pca$sdev^2)
    
    df_plotting<-data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2],colData) ### do PC2 = pca$x[, 2]*-1 to invert values
    
    ## Comment below to exclude 1.5 h samples
    #df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","1.5","3","12","24","24_control"))
    
    
    ## Uncomment below to exclude 1.5 h samples
    df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0_control","3","12","24","24_control"))
    
    ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=time_point, shape=species), size=6)+
      geom_text_repel(label=as.character(rownames(df_plotting)), size = 4, segment.color = "black",arrow = arrow(length = unit(0, 'npc')))+
      xlab(paste0("PC1: ",round(percentVar[1]*100),"% variance")) +
      ylab(paste0("PC2: ",round(percentVar[2]*100),"% variance")) + 
      coord_fixed()+ theme_bw()+labs(shape="Species", colour="Time point (h)")+colScale+
      guides(colour = guide_legend(order = 1),size = guide_legend(order = 2))+
      theme(axis.text = element_text(size = 16),axis.title = element_text(size=16),
            legend.text = element_text(size=14),legend.title = element_text(size=14))+
      ggsave("./all_spp_comparisons/human_pca_all_genes_no_1.5.png", units="in", width=10, heigh=7, dpi=600)
      
  }
}



### This generates PCA with RUVg k=1. To make the same for k=2 and k=3, change the value of k in :
### RUVg(set_to_remove_batch, as.character(overlap_for_batch$genes), k=1)
### and change "~ W_1 + batch" to "~ W_1 + W_2 + batch" for k=2, and "~ W_1+W_2+W_3+ batch" for k=3

deseq2_human("with dead and ece1") 

### This generates PCA without samples interacting with ece1 C. albicans and dead fungal cells.
deseq2_human("no dead and ece1")


detach("package:RUVSeq", unload=TRUE)   ### detach RUVSeq because it interferes with some functions of DESeq2
detach("package:EDASeq", unload=TRUE)   ### detach EDASeq because it interferes with some functions of DESeq2


############################
######## YEAST #############
############################


### import ortholog table

orthologs<-read.table("./orthologs.txt", sep="\t", header = TRUE)
colnames(orthologs)<-c("calb","calb_orf","ctrop","ctrop_gene","cpar","cglab")
orthologs$ctrop<-gsub("\\.1","",orthologs$ctrop)   ### remove .1 from CTROP gene ids

##### PCA 

for (specie in c("calb","cglab","cpar","ctrop")){
  gene_length<-read.table(paste0("./",specie,"_gene_id_start_end.txt"))
  gene_length_ordered<<-gene_length[order(gene_length$V1),]
  
  count_data<-read.table(paste0("./",specie,"/",toupper(specie),"_counts.txt"),sep = "\t",row.names = 1, check.names = FALSE)
  count_data_order<<-count_data[order(row.names(count_data)),]
  
  count_data_norm<-count_data_order/abs(gene_length_ordered$V3 - gene_length_ordered$V2)*1000
  assign(paste0(specie,"_norm_counts_orth"),eval(parse(text=paste0("count_data_norm[as.character(orthologs$",specie,"),]"))))
  }

all_yeast_data<-cbind.data.frame(calb_norm_counts_orth,
                                 cglab_norm_counts_orth,
                                 cpar_norm_counts_orth,
                                 ctrop_norm_counts_orth)

all_yeast_data<-all_yeast_data[complete.cases(all_yeast_data),]

all_yeast_data_reordered<-all_yeast_data[,c("6","7","8","21","22","23","34","35","36+reseq","47","48","49",
  "11","12","13","24plus24reseq","25","26","37+reseq","38","39","50","51","52+reseq",
  "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")]

colnames(all_yeast_data_reordered)<-c("6","7","8","21","22","23","34","35","36+reseq","47","48","49",
                                            "11","12","13","24+reseq","25","26","37+reseq","38","39","50","51","52+reseq",
                                            "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")


species<-c(c(rep(c(rep("calb",3),rep("cglab",3),rep("cpar",3),rep("ctrop",3)),2)),c(rep("calb",4),rep("cglab",3),rep("cpar",3),rep("ctrop",3)))
time_point<-c(rep("3",12),rep("12",12),rep("24",13))
annot_yeast<-data.frame(species=species, time_point=time_point)
rownames(annot_yeast)<-colnames(all_yeast_data_reordered)

tpm <- t(t(all_yeast_data_reordered)/colSums(all_yeast_data_reordered))*1e6+0.1
tpm_log<-log2(tpm+0.01)
pca_yeast<-prcomp(t(tpm_log))

percentVar <- pca_yeast$sdev^2/sum(pca_yeast$sdev^2)

df_plotting<-data.frame(PC1 = pca_yeast$x[, 1], PC2 = pca_yeast$x[, 2],annot_yeast) ### do PC2 = pca$x[, 2]*-1 to invert values

df_plotting$time_point<-factor(df_plotting$time_point, levels = c("3","12","24"))
ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=species, shape=time_point), size=5)+
  geom_text_repel(label=as.character(rownames(df_plotting)), size = 3, segment.color = "black",arrow = arrow(length = unit(0, 'npc')))+
  xlab(paste0("PC1: ",round(percentVar[1]*100),"% variance")) +
  ylab(paste0("PC2: ",round(percentVar[2]*100),"% variance")) + theme_bw()+labs(colour="Species", shape="Time point (h)")+
  guides(color = guide_legend(order=1), shape = guide_legend(order=2))+
  theme(axis.text = element_text(size = 14),axis.title = element_text(size=14))+
  scale_color_manual(values=c('red2','tan1', 'slateblue',"green1"))+
  ggsave("./all_spp_comparisons/fungal_pca.png", units="in", width=6, heigh=4, dpi=300)



#### PCA plot with 0 time point 


#### PCA plot with 0 time point 

#Comment this to exclude 1.5h
#all_yeast_data_reordered_with_0<-all_yeast_data[,c("1","2","A0C1+reseq","A0C2+reseq","19","20a","32","33","45","45C+reseq","46a",
#                                                   "3plus3reseq","4","5a",
#                                                   "6","7","8","21","22","23","34","35","36+reseq","47","48","49",
#                                                   "11","12","13","24plus24reseq","25","26","37+reseq","38","39","50","51","52+reseq",
#                                                   "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")]
#
#
#
#colnames(all_yeast_data_reordered_with_0)<-c("1","2","A0C1+reseq","A0C2+reseq","19","20a","32","33","45","45C+reseq","46a",
#                                             "3+reseq","4","5a",
#                                             "6","7","8","21","22","23","34","35","36+reseq","47","48","49",
#                                             "11","12","13","24+reseq","25","26","37+reseq","38","39","50","51","52+reseq",
#                                             "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")
#
#
#species_with_0<-c(c(rep("calb",4),rep("cglab",2),rep("cpar",2),rep("ctrop",3),rep("calb",3)),c(rep(c(rep("calb",3),rep("cglab",3),rep("cpar",3),rep("ctrop",3)),2)),c(rep("calb",4),rep("cglab",3),rep("cpar",3),rep("ctrop",3)))
#time_point_with_0<-c(rep("0",11),rep("1.5",3),rep("3",12),rep("12",12),rep("24",13))



#Uncomment this to exclude 1.5h
all_yeast_data_reordered_with_0<-all_yeast_data[,c("1","2","A0C1+reseq","A0C2+reseq","19","20a","32","33","45","45C+reseq","46a",
                                                   #"3plus3reseq","4","5a",
                                                   "6","7","8","21","22","23","34","35","36+reseq","47","48","49",
                                                   "11","12","13","24plus24reseq","25","26","37+reseq","38","39","50","51","52+reseq",
                                                   "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")]




colnames(all_yeast_data_reordered_with_0)<-c("1","2","A0C1+reseq","A0C2+reseq","19","20a","32","33","45","45C+reseq","46a",
                                             #"3+reseq","4","5a",
                                             "6","7","8","21","22","23","34","35","36+reseq","47","48","49",
                                             "11","12","13","24+reseq","25","26","37+reseq","38","39","50","51","52+reseq",
                                             "14","15","16","59","27","28","29","40","41","42","53+reseq","54","55")


species_with_0<-c(c(rep("calb",4),rep("cglab",2),rep("cpar",2),rep("ctrop",3)),c(rep(c(rep("calb",3),rep("cglab",3),rep("cpar",3),rep("ctrop",3)),2)),c(rep("calb",4),rep("cglab",3),rep("cpar",3),rep("ctrop",3)))
time_point_with_0<-c(rep("0",11),rep("3",12),rep("12",12),rep("24",13))




annot_yeast_with_0<-data.frame(species=species_with_0, time_point=time_point_with_0)
rownames(annot_yeast_with_0)<-colnames(all_yeast_data_reordered_with_0)

tpm <- t(t(all_yeast_data_reordered_with_0)/colSums(all_yeast_data_reordered_with_0))*1e6

tpm_log<-log2(tpm+0.01)

pca_yeast<-prcomp(t(tpm_log))

percentVar <- pca_yeast$sdev^2/sum(pca_yeast$sdev^2)

df_plotting<-data.frame(PC1 = pca_yeast$x[, 1], PC2 = pca_yeast$x[, 2],annot_yeast_with_0) ### do PC2 = pca$x[, 2]*-1 to invert values

#Comment this to exclude 1.5h
#df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0","1.5","3","12","24"))

# Uncomment this to exclude 1.5h
df_plotting$time_point<-factor(df_plotting$time_point, levels = c("0","3","12","24"))


ggplot(df_plotting, aes(PC1,PC2,label=rownames(df_plotting)))+geom_point(aes(colour=species, shape=time_point), size=5)+
  geom_text_repel(label=as.character(rownames(df_plotting)), size = 3, segment.color = "black",arrow = arrow(length = unit(0, 'npc')))+
  xlab(paste0("PC1: ",round(percentVar[1]*100),"% variance")) +
  ylab(paste0("PC2: ",round(percentVar[2]*100),"% variance")) + theme_bw()+labs(colour="Species", shape="Time point (h)")+
  guides(color = guide_legend(order=1), shape = guide_legend(order=2))+
  theme(axis.text = element_text(size = 14),axis.title = element_text(size=14))+
  scale_color_manual(values=c('salmon','tan1', 'slateblue',"green1"))+
  ggsave("./all_spp_comparisons/fungal_pca_with_0h_no_1.5.png", units="in", width=8, heigh=5, dpi=300)



#### Venn diagrams for each time point and barplot
venn_and_bar_yeast_3categories<-function(sign,lfc){
  bar_plot<-NULL
  for (timepoint in c("3","12","24")){
    for (yeast_specie in c("calb","cglab","cpar","ctrop")){
      data_yeast<-read.table(file=sprintf("./%s/res_%s_0_vs_%s.txt",yeast_specie,yeast_specie,timepoint))
      DEG<-rownames(data_yeast[!is.na(data_yeast$padj) & eval(parse(text=paste0("data_yeast$log2FoldChange",sign," ",lfc))) & data_yeast$padj<0.01,])
      assign(paste0("DEG_",yeast_specie),DEG)
      
      #####
      yeast_spp_spec_genes<-read.table(file=sprintf("./%s_specific.txt",yeast_specie))
      yeast_spp_spec_genes<-as.vector(yeast_spp_spec_genes$V1)
      
      DEG_spp_spec<-length(intersect(yeast_spp_spec_genes,DEG))
      N_spp_spec<-length(yeast_spp_spec_genes)
      
      #####
      assign(paste0("pre_",yeast_specie,"_orth"),orthologs[eval(parse(text=paste0("orthologs$",yeast_specie))) %in% eval(parse(text=paste0("DEG_",yeast_specie))),]) ### equivalent to # pre_cpar_orth<-orthologs[orthologs$CPAR %in%  DEG_cpar,]
      assign(paste0(yeast_specie,"_orth"),as.vector(eval(parse(text=paste0("pre_",yeast_specie,"_orth$calb")))))   ### equivalent to # cpar_orth<-as.vector(pre_cpar_orth$CALB)
      
      bar_plot<-rbind(bar_plot,c(timepoint,yeast_specie,paste0(yeast_specie,"_",timepoint),dim(eval(parse(text=paste0("pre_",yeast_specie,"_orth"))))[1],'fully shared'))   ### adding orthologous DE genes to bar_plot dataframe
      bar_plot<-rbind(bar_plot,c(timepoint,yeast_specie,paste0(yeast_specie,"_",timepoint),DEG_spp_spec,"species-specific")) ### species-specific
      bar_plot<-rbind(bar_plot,c(timepoint,yeast_specie,paste0(yeast_specie,"_",timepoint),length(eval(parse(text=paste0("DEG_",yeast_specie))))-dim(eval(parse(text=paste0("pre_",yeast_specie,"_orth"))))[1]-DEG_spp_spec,"partially shared")) ### adding non-orthologous DE genes to bar_plot dataframe
    }
    
    venn.diagram(list("DEG in C. alb."=calb_orth,
                      "DEG in C. par."=cpar_orth,
                      "DEG in C. trop."=ctrop_orth,
                      "DEG in C. glab."=cglab_orth),
                 fill=c("red", "blue", "green", "orange"), height = 2500, width = 2500, resolution = 600, 
                 main = paste0("Response of 4 yeast species at ",timepoint,"h\n (p<0.01, L2FC",sign,lfc,")"), cat.cex=0.4, cex=2.1, main.cex = 0.7, 
                 filename=paste0("./all_spp_comparisons/y_venn_",timepoint,"_L2FC",sign,lfc,".png"), print.mode = c("raw"),  
                 imagetype = "png")
  }

  colnames(bar_plot)<-c("timepoint","specie","specie_time","N_DEG","orthology")
  bar_plot<-as.data.frame(bar_plot)
  
  bar_plot$orthology <- factor(bar_plot$orthology, levels = c("species-specific","partially shared","fully shared"))
  bar_plot$N_DEG <- as.numeric(as.character(bar_plot$N_DEG))
  bar_plot$timepoint <- factor(bar_plot$timepoint, levels = c("3", "12", "24"))
  bar_plot<-group_by(bar_plot, specie_time) %>% mutate(percent = N_DEG/sum(N_DEG)*100)
  
  if (sign==">"){
    
    bar_plot_up_out_of_function<<-bar_plot  
    ggplot(data=bar_plot, aes(y = bar_plot$N_DEG, x = bar_plot$specie, fill = bar_plot$orthology, label=round(bar_plot$percent,1)))+
      geom_bar(stat="identity",position='stack') + facet_grid(~ bar_plot$timepoint)+geom_text(size = 6.5, position = position_stack(vjust = 0.5))+
      ylab("Number of DE genes") + xlab("Time(h)")+ guides(fill=guide_legend(title="Orthology status"))+
      scale_fill_manual(values = c("grey","steelblue2","darkseagreen"))+theme_bw()+
      theme(axis.text = element_text(size = 25),axis.title = element_text(size=25),
            legend.text = element_text(size=14),legend.title = element_text(size=14),
            axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank(),
            strip.background = element_blank(),
            strip.text.x = element_blank())+
      scale_x_discrete(position = "top") +
      scale_y_continuous(breaks=seq(0,1000,200))+
      ggsave(paste0("./all_spp_comparisons/bar_plot_L2FC",sign,lfc,"_3categories.png"), width = 13, height = 4,dpi = 600)}
  
  else{
    
    bar_plot_down_out_of_function<<-bar_plot
    ggplot(data=bar_plot, aes(y = bar_plot$N_DEG, x = bar_plot$specie, fill = bar_plot$orthology, label=round(bar_plot$percent,1)))+
      geom_bar(stat="identity",position='stack') + facet_grid(~ bar_plot$timepoint)+geom_text(size = 6.5,angle = 0, position = position_stack(vjust = 0.5))+
      ylab("Number of DE genes") + xlab("Time(h)")+ guides(fill=guide_legend(title="Orthology status"))+
      scale_fill_manual(values = c("grey","steelblue2","darkseagreen"))+theme_bw()+
      theme(axis.text = element_text(size = 25),axis.title = element_text(size=25),
            legend.text = element_text(size=14),legend.title = element_text(size=14),
            axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank(),
            strip.background = element_blank(),
            strip.text.x = element_blank())+
      scale_y_reverse(breaks=seq(0,1000,200))+
      ggsave(paste0("./all_spp_comparisons/bar_plot_L2FC",sign,lfc,"_3categories.png"), width = 13, height = 4,dpi = 600)
    
  }
  
}

venn_and_bar_yeast_3categories(">",0)
venn_and_bar_yeast_3categories(">",1.5)
venn_and_bar_yeast_3categories("<",0)
venn_and_bar_yeast_3categories("<",-1.5)



#### overrepresentation test

over_representation<-function(species,N_genes){
  
  spp_spec <- vector()
  fully_shared <- vector()
  partially_shared <- vector()
  
    for (timepoint in c("3","12","24")){
      data_yeast<-read.table(file=sprintf("./%s/res_%s_0_vs_%s.txt",species,species,timepoint))
      DEG<-rownames(data_yeast[!is.na(data_yeast$padj) & abs(data_yeast$log2FoldChange)>1.5 & data_yeast$padj<0.01,])
      yeast_spp_spec_genes<-read.table(file=sprintf("./%s_specific.txt",species))
      yeast_spp_spec_genes<-as.vector(yeast_spp_spec_genes$V1)
      N_spp_spec<-length(yeast_spp_spec_genes)
      
      DEG_spp_spec<-intersect(yeast_spp_spec_genes,DEG)
      
      spp_spec<-c(spp_spec,DEG_spp_spec)
      
      ### orthologs
      DEG_orth_table<-orthologs[eval(parse(text=paste0("orthologs$",species))) %in% DEG,]
      DEG_orth<-as.vector(eval(parse(text=paste0("DEG_orth_table$",species))))   
      
      fully_shared<-c(fully_shared,DEG_orth)
      
      ### partially shared
      DEG_partially_shared<-setdiff(DEG,c(DEG_spp_spec,DEG_orth))

      partially_shared<-c(partially_shared,DEG_partially_shared)

    }
  
  spp_spec <- unique(spp_spec)
  fully_shared <- unique(fully_shared)
  partially_shared <- unique (partially_shared)
  

  matr<-as.matrix(rbind(c(length(fully_shared),length(spp_spec)),
                             c(3639-length(fully_shared),N_spp_spec-length(spp_spec))))
  colnames(matr)<-c("fully_shared","Spp_spec")
  rownames(matr)<-c("DE","Non-DE")
  print(matr)
  
  fish<-fisher.test(matr)
  hyper<-dhyper(length(spp_spec),N_spp_spec,N_genes-N_spp_spec,length(DEG), log = FALSE)
  chi<-chisq.test(matr)
  
  print(paste0("Fisher result for ",species," is: "))
  print(fish)
  print(paste0("Dhyper result for ",species, " is (NOTE: comparison against spp-specific genes and all the rest): " , hyper))

  print(paste0("Chi-square result for ",species, " is "))
  print(chi)

}

over_representation("calb",6468)
over_representation("cglab",5615)
over_representation("cpar",5984)
over_representation("ctrop",6461)

#################################
#### Infection genes across species

infection_genes_barplots_3categories<-function(sign,lfc,species){
  bar_plot<-NULL
  for (specie in species){
    file<-read.table(file=sprintf("%s/infection_genes_%s_24_24c.txt",specie,specie))
    gene_names<-rownames(file[eval(parse(text=paste0("file$log2FoldChange",sign," ",lfc))) ,]) ### & file$baseMean>10
    
    assign(paste0("pre_",specie,"_orth"),orthologs[eval(parse(text=paste0("orthologs$",specie))) %in% gene_names,]) ### equivalent to # pre_cpar_orth<-orthologs[orthologs$CPAR %in%  DEG_cpar,]
    assign(paste0(specie,"_orth"),as.vector(eval(parse(text=paste0("pre_",specie,"_orth$calb")))))   ### equivalent to # cpar_orth<-as.vector(pre_cpar_orth$CALB) #### put "pre_",specie,"_orth$specie" to get gene-ids for that species, not for calb
    
    assign(paste0(specie,"_non_orth"),setdiff(gene_names,eval(parse(text=paste0(specie,"_orth")))))
    
    
    #####
    yeast_spp_spec_genes<-read.table(file=sprintf("./%s_specific.txt",specie))
    yeast_spp_spec_genes<-as.vector(yeast_spp_spec_genes$V1)
    
    DEG_spp_spec<-length(intersect(yeast_spp_spec_genes,gene_names))
    N_spp_spec<-length(yeast_spp_spec_genes)
    
    #####
    
    
    
    bar_plot<-rbind(bar_plot,c(specie,dim(eval(parse(text=paste0("pre_",specie,"_orth"))))[1],'fully shared'))   ### adding orthologous DE genes to bar_plot dataframe
    bar_plot<-rbind(bar_plot,c(specie,DEG_spp_spec,'species-specific'))
    
    bar_plot<-rbind(bar_plot,c(specie,length(gene_names)-dim(eval(parse(text=paste0("pre_",specie,"_orth"))))[1]-DEG_spp_spec,"partially shared")) ### adding non-orthologous DE genes to bar_plot dataframe
    print(bar_plot)
  }
  
  
  if (length(species)==4){
    print("4 species")
    venn.diagram(list("C. alb."=calb_orth,
                      "C. par."=cpar_orth,
                      "C. trop."=ctrop_orth,
                      "C. glab."=cglab_orth),
                 fill=c("red", "blue", "green", "orange"), height = 2500, width = 2500, resolution = 600, 
                 main = paste0("Infection-specific orthologous DEG in 4 spp.\n (p<0.01, L2FC",sign,lfc,")"), cat.cex=0.4, cex=2.1, main.cex = 0.7, 
                 filename=paste0("./all_spp_comparisons/Inf_genes_candida_LFC",sign,lfc,".png"),  
                 imagetype = "png")
  }

  colnames(bar_plot)<-c("specie","N_DEG","orthology")
  bar_plot<-as.data.frame(bar_plot)
  
  bar_plot$N_DEG<-as.numeric(as.character(bar_plot$N_DEG))
  bar_plot$orthology <- factor(bar_plot$orthology, levels = c("species-specific", "partially shared","fully shared"))
  bar_plot<-group_by(bar_plot, specie) %>% mutate(percent = N_DEG/sum(N_DEG)*100)
  print(bar_plot)
  
  if (sign==">"){
    
    ggplot(data=bar_plot, aes(y = bar_plot$N_DEG, x = bar_plot$specie, fill = bar_plot$orthology, label=round(bar_plot$percent),2))+
      geom_bar(stat="identity",position='stack') + geom_text(size = 6.5, position = position_stack(vjust = 0.5))+
      ylab("Number of DE genes") + xlab("Species")+guides(fill=guide_legend(title="Orthology status"))+
      scale_fill_manual(values = c("grey","steelblue2","darkseagreen" ))+theme_bw()+ylim(0,160)+
      theme(axis.text = element_text(size = 25),axis.title = element_text(size=25),
            legend.text = element_text(size=14),legend.title = element_text(size=14),
            axis.title.x=element_blank(),
            axis.ticks.x=element_blank(),
            strip.background = element_blank(),
            strip.text.x = element_blank())+
      ggsave(paste0("./all_spp_comparisons/barplot_inf_genes_L2FC",sign,lfc,"_3categories.png"), width = 10, height = 7,dpi = 600)
  }
  else{
    ggplot(data=bar_plot, aes(y = bar_plot$N_DEG, x = bar_plot$specie, fill = bar_plot$orthology, label=round(bar_plot$percent),2))+
      geom_bar(stat="identity",position='stack') + geom_text(size = 6.5, position = position_stack(vjust = 0.5))+
      ylab("Number of DE genes") + xlab("Species")+guides(fill=guide_legend(title="Orthology status"))+
      scale_fill_manual(values = c("grey","steelblue2","darkseagreen"))+theme_bw()+
      theme(axis.text = element_text(size = 25),axis.title = element_text(size=25),
            legend.text = element_text(size=14),legend.title = element_text(size=14),
            axis.title.x=element_blank(),
            axis.ticks.x=element_blank(),
            strip.background = element_blank(),
            strip.text.x = element_blank())+
      ggsave(paste0("./all_spp_comparisons/barplot_inf_genes_L2FC",sign,lfc,"_3categories.png"), width = 10, height = 7,dpi = 600)
    
    
  } 
}

infection_genes_barplots_3categories(">",1.5,c("calb","cglab","cpar","ctrop"))
infection_genes_barplots_3categories("<",-1.5,c("calb","cglab","cpar","ctrop"))


### GENERAL GO TERMS. The plots will need minor manual rearrangements to match the ones reported in the paper. Can be done by e.g. Inkscape free software.

group_up<-NULL
group_down<-NULL
for (specie in c("calb", "cglab", "cpar", "ctrop")){
  for (time in c("3","12","24")){                      
    data<-read.table(file=sprintf("%s/res_human_%s_0_vs_%s.txt",specie,specie,time))
    
    data_up<-data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange>1.5,]
    data_down<-data[!is.na(data$padj) & data$padj<0.01 & data$log2FoldChange< -1.5,]
    
    data_up_subset<-cbind.data.frame(rownames(data_up),data_up$log2FoldChange,specie, paste0(time,"h"))
    data_down_subset<-cbind.data.frame(rownames(data_down),data_down$log2FoldChange,specie, paste0(time,"h"))
    
    
    group_up<-rbind(group_up,data_up_subset)
    group_down<-rbind(group_down,data_down_subset)

  }
}
colnames(group_up)<-c("genes","l2fc","Specie","Timepoint")
colnames(group_down)<-c("genes","l2fc","Specie","Timepoint")

formula_res_up <- compareCluster(genes~Specie+Timepoint,OrgDb = org.Hs.eg.db, data=group_up, ont = "BP",keyType="ENSEMBL", fun="enrichGO")
formula_res_up_to_plot<-formula_res_up
df<-as.data.frame(formula_res_up_to_plot)
df$GeneRatio<-1
df$Timepoint<-factor(df$Timepoint, levels = c("3h","12h","24h"))
formula_res_up_to_plot@compareClusterResult<-df
pup<-dotplot(formula_res_up_to_plot,showCategory=10)+ ggplot2::facet_grid(~Timepoint, scales = "free")
pup+ggplot2::ggsave("./all_spp_comparisons/human_GO_general_up.png",units="in", width=12, heigh=9, dpi=600)


### generate file with all GO terms


system("ls {calb,ctrop,cpar,cglab}/{human,fungi}/res*txt > go_file_list.txt")
system("python concat_go_files.py")

all_GO_data<-read.csv("all_GO_tems.txt", header = T, sep = "\t")


wb_S9 <- createWorkbook("Supp_file_S9.xlsx")
addWorksheet(wb_S9, "all_GO_terms")
writeData(wb_S9, "all_GO_terms", all_GO_data,keepNA = T)
saveWorkbook(wb_S9, "Supp_file_S9.xlsx", overwrite = TRUE)

#### plot fungal go terms


plot_fungal_go<-function(go_data,direction,human_res_file){
  
all_GO_data_fungal<-go_data[!grepl("human",go_data$Species) &
                              go_data$Time_comparison %in% c("0_vs_3","0_vs_12","0_vs_24") &
                              go_data$Up_or_Down_regulated == direction &
                              go_data$GO_category == "BP",]


all_GO_data_fungal$Timepoint<-ifelse(grepl("0_vs_3",all_GO_data_fungal$Time_comparison),"3h",
                                    ifelse(grepl("0_vs_12",all_GO_data_fungal$Time_comparison),"12h","24h"))
                                    
all_GO_data_fungal$Cluster<-paste0(as.character(all_GO_data_fungal$Species),".",all_GO_data_fungal$Timepoint)


all_GO_data_fungal_to_plot<-cbind.data.frame("Cluster"=all_GO_data_fungal$Cluster,"Spp"=all_GO_data_fungal$Species,"Timepoint"=all_GO_data_fungal$Timepoint,
                                             "ID"=all_GO_data_fungal$GO_id,"Description"=all_GO_data_fungal$Description,"GeneRatio"=1,"BgRatio"=1,
                                             "pval"=all_GO_data_fungal$Adj_p.value,"p.adjust"=all_GO_data_fungal$Adj_p.value,"qval"=0.1,
                                             "geneID"=all_GO_data_fungal$Genes,"Count"=1)


all_GO_data_fungal_to_plot$Timepoint<-factor(all_GO_data_fungal_to_plot$Timepoint, levels = c("3h","12h","24h"))


### hacking clusterProfile
formula_res_up_to_plot_fungal<-human_res_file

formula_res_up_to_plot_fungal@compareClusterResult<-all_GO_data_fungal_to_plot

fung<-dotplot(formula_res_up_to_plot_fungal, showCategory=8)+ ggplot2::facet_grid(~Timepoint,scales = "free")
fung+ggplot2::ggsave(sprintf("./all_spp_comparisons/fungal_GO_general_%s.png",direction),units="in", width=15, heigh=9, dpi=600)

}

plot_fungal_go(all_GO_data,"up",formula_res_up)

writeLines(capture.output(sessionInfo()), "sessionInfo.txt")
